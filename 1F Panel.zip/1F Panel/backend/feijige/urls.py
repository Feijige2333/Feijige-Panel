from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('api.urls')),
    path('api/server/', include('server_mgmt.urls')),
    path('api/website/', include('website_mgmt.urls')),
    path('api/database/', include('database_mgmt.urls')),
    path('api/security/', include('security_mgmt.urls')),
    path('api/user/', include('user_mgmt.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)