from django.contrib.auth.models import User
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import UserProfile, UserPermission, UserLoginLog, UserOperationLog
from .serializers import UserSerializer, UserProfileSerializer, UserPermissionSerializer, UserLoginLogSerializer, UserOperationLogSerializer

class UserViewSet(viewsets.ModelViewSet):
    """用户管理视图集"""
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAdminUser]
    
    def perform_create(self, serializer):
        user = serializer.save()
        # 创建用户配置文件
        UserProfile.objects.create(user=user)
        # 记录操作日志
        self.record_operation_log(user, 'create', f'创建用户: {user.username}')
    
    def perform_update(self, serializer):
        user = serializer.save()
        # 记录操作日志
        self.record_operation_log(user, 'update', f'更新用户: {user.username}')
    
    def perform_destroy(self, instance):
        username = instance.username
        instance.delete()
        # 记录操作日志
        self.record_operation_log(None, 'delete', f'删除用户: {username}')
    
    @action(detail=True, methods=['post'])
    def set_permissions(self, request, pk=None):
        """设置用户权限"""
        user = self.get_object()
        permissions_data = request.data.get('permissions', [])
        
        # 清除现有权限
        user.permissions.all().delete()
        
        # 添加新权限
        for perm_type in permissions_data:
            UserPermission.objects.create(user=user, permission_type=perm_type)
        
        # 记录操作日志
        self.record_operation_log(user, 'update', f'更新用户权限: {user.username}')
        
        return Response({'status': 'permissions set'}, status=status.HTTP_200_OK)
    
    @action(detail=False, methods=['get'])
    def current_user(self, request):
        """获取当前登录用户信息"""
        serializer = self.get_serializer(request.user)
        return Response(serializer.data)
    
    def record_operation_log(self, target_user, action, detail):
        """记录操作日志"""
        UserOperationLog.objects.create(
            user=self.request.user,
            module='user',
            action=action,
            detail=detail,
            ip_address=self.get_client_ip()
        )
    
    def get_client_ip(self):
        """获取客户端IP地址"""
        x_forwarded_for = self.request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = self.request.META.get('REMOTE_ADDR')
        return ip

class UserLoginLogViewSet(viewsets.ReadOnlyModelViewSet):
    """用户登录日志视图集"""
    queryset = UserLoginLog.objects.all()
    serializer_class = UserLoginLogSerializer
    permission_classes = [permissions.IsAdminUser]
    
    def get_queryset(self):
        queryset = UserLoginLog.objects.all()
        username = self.request.query_params.get('username', None)
        if username is not None:
            queryset = queryset.filter(user__username=username)
        return queryset

class UserOperationLogViewSet(viewsets.ReadOnlyModelViewSet):
    """用户操作日志视图集"""
    queryset = UserOperationLog.objects.all()
    serializer_class = UserOperationLogSerializer
    permission_classes = [permissions.IsAdminUser]
    
    def get_queryset(self):
        queryset = UserOperationLog.objects.all()
        username = self.request.query_params.get('username', None)
        module = self.request.query_params.get('module', None)
        action = self.request.query_params.get('action', None)
        
        if username is not None:
            queryset = queryset.filter(user__username=username)
        if module is not None:
            queryset = queryset.filter(module=module)
        if action is not None:
            queryset = queryset.filter(action=action)
            
        return queryset