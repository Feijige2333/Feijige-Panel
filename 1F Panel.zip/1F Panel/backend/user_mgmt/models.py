from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    """用户配置文件，扩展Django默认用户模型"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone = models.CharField(max_length=20, blank=True, null=True, verbose_name='手机号')
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True, verbose_name='头像')
    is_active = models.BooleanField(default=True, verbose_name='是否激活')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    
    class Meta:
        verbose_name = '用户配置'
        verbose_name_plural = '用户配置'
        
    def __str__(self):
        return self.user.username

class UserPermission(models.Model):
    """用户权限模型"""
    PERMISSION_CHOICES = (
        ('admin', '管理员'),
        ('website', '网站管理'),
        ('database', '数据库管理'),
        ('security', '安全管理'),
        ('view_only', '只读权限'),
    )
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='permissions', verbose_name='用户')
    permission_type = models.CharField(max_length=20, choices=PERMISSION_CHOICES, verbose_name='权限类型')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    
    class Meta:
        verbose_name = '用户权限'
        verbose_name_plural = '用户权限'
        unique_together = ('user', 'permission_type')
        
    def __str__(self):
        return f'{self.user.username} - {self.get_permission_type_display()}'

class UserLoginLog(models.Model):
    """用户登录日志"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='login_logs', verbose_name='用户')
    ip_address = models.GenericIPAddressField(verbose_name='IP地址')
    user_agent = models.TextField(verbose_name='浏览器信息')
    login_time = models.DateTimeField(auto_now_add=True, verbose_name='登录时间')
    login_status = models.BooleanField(default=True, verbose_name='登录状态')
    
    class Meta:
        verbose_name = '登录日志'
        verbose_name_plural = '登录日志'
        ordering = ['-login_time']
        
    def __str__(self):
        return f'{self.user.username} - {self.login_time}'

class UserOperationLog(models.Model):
    """用户操作日志"""
    ACTION_CHOICES = (
        ('create', '创建'),
        ('update', '更新'),
        ('delete', '删除'),
        ('view', '查看'),
        ('other', '其他'),
    )
    
    MODULE_CHOICES = (
        ('server', '服务器管理'),
        ('website', '网站管理'),
        ('database', '数据库管理'),
        ('security', '安全管理'),
        ('user', '用户管理'),
        ('setting', '系统设置'),
    )
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='operation_logs', verbose_name='用户')
    module = models.CharField(max_length=20, choices=MODULE_CHOICES, verbose_name='操作模块')
    action = models.CharField(max_length=20, choices=ACTION_CHOICES, verbose_name='操作类型')
    detail = models.TextField(verbose_name='操作详情')
    ip_address = models.GenericIPAddressField(verbose_name='IP地址')
    operation_time = models.DateTimeField(auto_now_add=True, verbose_name='操作时间')
    
    class Meta:
        verbose_name = '操作日志'
        verbose_name_plural = '操作日志'
        ordering = ['-operation_time']
        
    def __str__(self):
        return f'{self.user.username} - {self.get_module_display()} - {self.get_action_display()}'