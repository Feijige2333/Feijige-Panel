from django.contrib.auth.models import User
from rest_framework import serializers
from .models import UserProfile, UserPermission, UserLoginLog, UserOperationLog

class UserProfileSerializer(serializers.ModelSerializer):
    """用户配置文件序列化器"""
    class Meta:
        model = UserProfile
        fields = ['id', 'phone', 'avatar', 'is_active', 'created_at', 'updated_at']

class UserPermissionSerializer(serializers.ModelSerializer):
    """用户权限序列化器"""
    permission_name = serializers.CharField(source='get_permission_type_display', read_only=True)
    
    class Meta:
        model = UserPermission
        fields = ['id', 'permission_type', 'permission_name', 'created_at']

class UserSerializer(serializers.ModelSerializer):
    """用户序列化器"""
    profile = UserProfileSerializer(read_only=True)
    permissions = UserPermissionSerializer(many=True, read_only=True)
    password = serializers.CharField(write_only=True, required=False)
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'is_staff', 
                  'is_active', 'date_joined', 'profile', 'permissions', 'password']
    
    def create(self, validated_data):
        password = validated_data.pop('password', None)
        user = User.objects.create(**validated_data)
        if password:
            user.set_password(password)
            user.save()
        return user
    
    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        user = super().update(instance, validated_data)
        if password:
            user.set_password(password)
            user.save()
        return user

class UserLoginLogSerializer(serializers.ModelSerializer):
    """用户登录日志序列化器"""
    username = serializers.CharField(source='user.username', read_only=True)
    
    class Meta:
        model = UserLoginLog
        fields = ['id', 'user', 'username', 'ip_address', 'user_agent', 'login_time', 'login_status']

class UserOperationLogSerializer(serializers.ModelSerializer):
    """用户操作日志序列化器"""
    username = serializers.CharField(source='user.username', read_only=True)
    module_name = serializers.CharField(source='get_module_display', read_only=True)
    action_name = serializers.CharField(source='get_action_display', read_only=True)
    
    class Meta:
        model = UserOperationLog
        fields = ['id', 'user', 'username', 'module', 'module_name', 'action', 
                  'action_name', 'detail', 'ip_address', 'operation_time']