from django.db import models

class SystemSetting(models.Model):
    """系统设置模型"""
    THEME_CHOICES = (
        ('light', '浅色主题'),
        ('dark', '深色主题'),
        ('auto', '跟随系统'),
    )
    
    LANGUAGE_CHOICES = (
        ('zh-CN', '简体中文'),
        ('en-US', '英文'),
    )
    
    key = models.CharField(max_length=50, unique=True, verbose_name='设置键名')
    value = models.TextField(verbose_name='设置值')
    description = models.CharField(max_length=255, blank=True, null=True, verbose_name='设置描述')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    
    class Meta:
        verbose_name = '系统设置'
        verbose_name_plural = '系统设置'
        
    def __str__(self):
        return f'{self.key}: {self.value}'

class BackupRecord(models.Model):
    """备份记录模型"""
    BACKUP_TYPE_CHOICES = (
        ('full', '全量备份'),
        ('config', '配置备份'),
        ('database', '数据库备份'),
        ('website', '网站备份'),
    )
    
    name = models.CharField(max_length=100, verbose_name='备份名称')
    backup_type = models.CharField(max_length=20, choices=BACKUP_TYPE_CHOICES, verbose_name='备份类型')
    file_path = models.CharField(max_length=255, verbose_name='文件路径')
    file_size = models.BigIntegerField(verbose_name='文件大小(字节)')
    description = models.TextField(blank=True, null=True, verbose_name='备份描述')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    
    class Meta:
        verbose_name = '备份记录'
        verbose_name_plural = '备份记录'
        ordering = ['-created_at']
        
    def __str__(self):
        return self.name

class UpdateRecord(models.Model):
    """更新记录模型"""
    STATUS_CHOICES = (
        ('available', '可更新'),
        ('downloading', '下载中'),
        ('installing', '安装中'),
        ('completed', '已完成'),
        ('failed', '失败'),
    )
    
    version = models.CharField(max_length=50, verbose_name='版本号')
    release_notes = models.TextField(verbose_name='发布说明')
    download_url = models.URLField(verbose_name='下载地址')
    file_size = models.BigIntegerField(verbose_name='文件大小(字节)')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available', verbose_name='状态')
    release_date = models.DateField(verbose_name='发布日期')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    
    class Meta:
        verbose_name = '更新记录'
        verbose_name_plural = '更新记录'
        ordering = ['-release_date']
        
    def __str__(self):
        return f'v{self.version}'

class NotificationSetting(models.Model):
    """通知设置模型"""
    NOTIFICATION_TYPE_CHOICES = (
        ('email', '邮件通知'),
        ('sms', '短信通知'),
        ('wechat', '微信通知'),
        ('dingtalk', '钉钉通知'),
    )
    
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPE_CHOICES, verbose_name='通知类型')
    is_enabled = models.BooleanField(default=False, verbose_name='是否启用')
    config = models.JSONField(default=dict, verbose_name='配置信息')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    
    class Meta:
        verbose_name = '通知设置'
        verbose_name_plural = '通知设置'
        
    def __str__(self):
        return f'{self.get_notification_type_display()}: {"已启用" if self.is_enabled else "未启用"}'