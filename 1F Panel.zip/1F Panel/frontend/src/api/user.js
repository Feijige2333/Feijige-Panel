import request from '@/utils/request';

/**
 * 用户管理相关API服务
 */
export const userService = {
  /**
   * 创建新用户
   * @param {Object} userData - 用户数据
   * @returns {Promise} - 返回创建结果
   */
  createUser(userData) {
    return request({
      url: '/api/user/create',
      method: 'post',
      data: userData
    });
  },

  /**
   * 获取用户列表
   * @returns {Promise} - 返回用户列表
   */
  getUserList() {
    return request({
      url: '/api/user/list',
      method: 'get'
    });
  },

  /**
   * 更新用户信息
   * @param {String} userId - 用户ID
   * @param {Object} userData - 用户数据
   * @returns {Promise} - 返回更新结果
   */
  updateUser(userId, userData) {
    return request({
      url: `/api/user/${userId}`,
      method: 'put',
      data: userData
    });
  },

  /**
   * 删除用户
   * @param {String} userId - 用户ID
   * @returns {Promise} - 返回删除结果
   */
  deleteUser(userId) {
    return request({
      url: `/api/user/${userId}`,
      method: 'delete'
    });
  },

  /**
   * 设置用户权限
   * @param {String} userId - 用户ID
   * @param {Array} permissions - 权限列表
   * @returns {Promise} - 返回设置结果
   */
  setPermissions(userId, permissions) {
    return request({
      url: `/api/user/${userId}/permissions`,
      method: 'post',
      data: { permissions }
    });
  },

  /**
   * 上传用户头像
   * @param {FormData} formData - 包含头像文件的表单数据
   * @returns {Promise} - 返回上传结果
   */
  uploadAvatar(formData) {
    return request({
      url: '/api/user/upload-avatar',
      method: 'post',
      data: formData,
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
  }
};