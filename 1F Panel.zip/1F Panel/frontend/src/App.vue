<template>
  <div class="app-container">
    <el-container class="layout-container">
      <el-aside width="220px" class="aside">
        <div class="logo">
          <img src="./assets/logo.png" alt="Feijige Panel" class="logo-img" />
          <h1 class="logo-text">飞机哥面板</h1>
        </div>
        <el-menu
          :router="true"
          class="sidebar-menu"
          background-color="#001529"
          text-color="#fff"
          active-text-color="#409EFF"
        >
          <el-sub-menu index="1">
            <template #title>
              <el-icon><Monitor /></el-icon>
              <span>服务器管理</span>
            </template>
            <el-menu-item index="/dashboard">系统监控</el-menu-item>
            <el-menu-item index="/processes">进程管理</el-menu-item>
            <el-menu-item index="/services">服务管理</el-menu-item>
          </el-sub-menu>
          
          <el-sub-menu index="2">
            <template #title>
              <el-icon><Connection /></el-icon>
              <span>网站管理</span>
            </template>
            <el-menu-item index="/websites">网站列表</el-menu-item>
            <el-menu-item index="/website/create">创建网站</el-menu-item>
            <el-menu-item index="/website/backup">备份管理</el-menu-item>
            <el-menu-item index="/website/stats">流量统计</el-menu-item>
          </el-sub-menu>
          
          <el-sub-menu index="3">
            <template #title>
              <el-icon><DataBase /></el-icon>
              <span>数据库管理</span>
            </template>
            <el-menu-item index="/databases">数据库列表</el-menu-item>
            <el-menu-item index="/database/create">创建数据库</el-menu-item>
            <el-menu-item index="/database/import">数据导入导出</el-menu-item>
            <el-menu-item index="/database/optimize">性能优化</el-menu-item>
          </el-sub-menu>
          
          <el-sub-menu index="4">
            <template #title>
              <el-icon><Lock /></el-icon>
              <span>安全管理</span>
            </template>
            <el-menu-item index="/firewall">防火墙设置</el-menu-item>
            <el-menu-item index="/security/scan">漏洞扫描</el-menu-item>
            <el-menu-item index="/ssl">SSL证书</el-menu-item>
          </el-sub-menu>
          
          <el-sub-menu index="5">
            <template #title>
              <el-icon><User /></el-icon>
              <span>用户管理</span>
            </template>
            <el-menu-item index="/users">用户列表</el-menu-item>
            <el-menu-item index="/user/create">创建用户</el-menu-item>
            <el-menu-item index="/user/logs">登录日志</el-menu-item>
          </el-sub-menu>
          
          <el-sub-menu index="6">
            <template #title>
              <el-icon><Setting /></el-icon>
              <span>系统设置</span>
            </template>
            <el-menu-item index="/settings/general">常规设置</el-menu-item>
            <el-menu-item index="/settings/backup">备份设置</el-menu-item>
            <el-menu-item index="/settings/notification">通知设置</el-menu-item>
          </el-sub-menu>
        </el-menu>
      </el-aside>
      
      <el-container>
        <el-header class="header">
          <div class="header-left">
            <el-button type="text" @click="toggleSidebar">
              <el-icon><Fold /></el-icon>
            </el-button>
            <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
              <el-breadcrumb-item>{{ currentRoute }}</el-breadcrumb-item>
            </el-breadcrumb>
          </div>
          <div class="header-right">
            <el-dropdown>
              <span class="user-dropdown">
                <el-avatar size="small" src="./assets/avatar.png" />
                <span class="username">管理员</span>
              </span>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item>个人信息</el-dropdown-item>
                  <el-dropdown-item>修改密码</el-dropdown-item>
                  <el-dropdown-item divided>退出登录</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </el-header>
        
        <el-main class="main-content">
          <router-view />
        </el-main>
        
        <el-footer class="footer">
          Feijige Panel © {{ new Date().getFullYear() }} - 飞机哥服务器管理面板
        </el-footer>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import {
  Monitor,
  Connection,
  DataBase,
  Lock,
  User,
  Setting,
  Fold
} from '@element-plus/icons-vue'

const route = useRoute()
const isCollapse = ref(false)

const currentRoute = computed(() => {
  return route.meta.title || route.name || '首页'
})

const toggleSidebar = () => {
  isCollapse.value = !isCollapse.value
}
</script>

<style scoped>
.app-container {
  height: 100vh;
  width: 100%;
}

.layout-container {
  height: 100%;
}

.aside {
  background-color: #001529;
  color: #fff;
  height: 100vh;
  overflow-x: hidden;
}

.logo {
  height: 60px;
  display: flex;
  align-items: center;
  padding: 0 20px;
  background-color: #002140;
}

.logo-img {
  height: 32px;
  margin-right: 10px;
}

.logo-text {
  color: #fff;
  font-size: 18px;
  font-weight: 600;
  white-space: nowrap;
  margin: 0;
}

.sidebar-menu {
  border-right: none;
}

.header {
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  height: 60px;
}

.header-left {
  display: flex;
  align-items: center;
}

.header-right {
  display: flex;
  align-items: center;
}

.user-dropdown {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.username {
  margin-left: 8px;
  font-size: 14px;
}

.main-content {
  background-color: #f0f2f5;
  padding: 20px;
  height: calc(100vh - 120px);
  overflow-y: auto;
}

.footer {
  text-align: center;
  background-color: #f0f2f5;
  color: #666;
  font-size: 12px;
  padding: 10px 0;
  height: 40px;
  line-height: 20px;
}
</style>