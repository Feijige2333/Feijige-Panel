import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: '/dashboard'
    },
    {
      path: '/dashboard',
      name: 'dashboard',
      component: () => import('../views/Dashboard.vue'),
      meta: { title: '系统监控' }
    },
    {
      path: '/processes',
      name: 'processes',
      component: () => import('../views/Processes.vue'),
      meta: { title: '进程管理' }
    },
    {
      path: '/services',
      name: 'services',
      component: () => import('../views/Services.vue'),
      meta: { title: '服务管理' }
    },
    {
      path: '/websites',
      name: 'websites',
      component: () => import('../views/Websites.vue'),
      meta: { title: '网站列表' }
    },
    {
      path: '/website/create',
      name: 'websiteCreate',
      component: () => import('../views/WebsiteCreate.vue'),
      meta: { title: '创建网站' }
    },
    {
      path: '/website/backup',
      name: 'websiteBackup',
      component: () => import('../views/WebsiteBackup.vue'),
      meta: { title: '备份管理' }
    },
    {
      path: '/website/stats',
      name: 'websiteStats',
      component: () => import('../views/WebsiteStats.vue'),
      meta: { title: '流量统计' }
    },
    {
      path: '/settings/general',
      name: 'settingsGeneral',
      component: () => import('../views/settings/General.vue'),
      meta: { title: '常规设置' }
    },
    {
      path: '/settings/backup',
      name: 'settingsBackup',
      component: () => import('../views/settings/Backup.vue'),
      meta: { title: '备份设置' }
    },
    {
      path: '/settings/notification',
      name: 'settingsNotification',
      component: () => import('../views/settings/Notification.vue'),
      meta: { title: '通知设置' }
    },
    {
      path: '/users',
      name: 'users',
      component: () => import('../views/users/UserList.vue'),
      meta: { title: '用户列表' }
    },
    {
      path: '/user/create',
      name: 'userCreate',
      component: () => import('../views/users/UserCreate.vue'),
      meta: { title: '创建用户' }
    },
    {
      path: '/user/logs',
      name: 'userLogs',
      component: () => import('../views/users/UserLogs.vue'),
      meta: { title: '用户日志' }
    },
    {
      path: '/databases',
      name: 'databases',
      component: () => import('../views/Databases.vue'),
      meta: { title: '数据库列表' }
    },
    {
      path: '/database/create',
      name: 'databaseCreate',
      component: () => import('../views/DatabaseCreate.vue'),
      meta: { title: '创建数据库' }
    },
    {
      path: '/database/backup',
      name: 'databaseBackup',
      component: () => import('../views/DatabaseBackup.vue'),
      meta: { title: '数据库备份' }
    },
    {
      path: '/security',
      name: 'security',
      component: () => import('../views/Security.vue'),
      meta: { title: '安全设置' }
    },
    {
      path: '/firewall',
      name: 'firewall',
      component: () => import('../views/Firewall.vue'),
      meta: { title: '防火墙' }
    },
    {
      path: '/ssl',
      name: 'ssl',
      component: () => import('../views/SSL.vue'),
      meta: { title: 'SSL证书' }
    },
    {
      path: '/security-scan',
      name: 'securityScan',
      component: () => import('../views/SecurityScan.vue'),
      meta: { title: '安全扫描' }
    },
    {
      path: '/file-manager',
      name: 'fileManager',
      component: () => import('../views/FileManager.vue'),
      meta: { title: '文件管理' }
    },
    {
      path: '/users',
      name: 'users',
      component: () => import('../views/Users.vue'),
      meta: { title: '用户管理' }
    },
    {
      path: '/settings',
      name: 'settings',
      component: () => import('../views/Settings.vue'),
      meta: { title: '系统设置' }
    }
  ]
})

router.beforeEach((to, from, next) => {
  // 设置页面标题
  document.title = `${to.meta.title || '首页'} - Feijige Panel`
  next()
})

export default router