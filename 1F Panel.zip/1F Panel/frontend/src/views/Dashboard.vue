<template>
  <div class="dashboard-container">
    <el-row :gutter="20">
      <!-- 系统概览卡片 -->
      <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24">
        <el-card class="overview-card">
          <template #header>
            <div class="card-header">
              <h3>系统概览</h3>
              <el-button type="primary" size="small" @click="refreshData">刷新</el-button>
            </div>
          </template>
          <el-row :gutter="20">
            <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6">
              <div class="stat-item">
                <div class="stat-icon cpu">
                  <el-icon><cpu /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-title">CPU 使用率</div>
                  <div class="stat-value">{{ systemInfo.cpu }}%</div>
                  <el-progress :percentage="systemInfo.cpu" :color="getCpuColor(systemInfo.cpu)" />
                </div>
              </div>
            </el-col>
            <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6">
              <div class="stat-item">
                <div class="stat-icon memory">
                  <el-icon><connection /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-title">内存使用率</div>
                  <div class="stat-value">{{ systemInfo.memory }}%</div>
                  <el-progress :percentage="systemInfo.memory" :color="getMemoryColor(systemInfo.memory)" />
                </div>
              </div>
            </el-col>
            <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6">
              <div class="stat-item">
                <div class="stat-icon disk">
                  <el-icon><disk /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-title">磁盘使用率</div>
                  <div class="stat-value">{{ systemInfo.disk }}%</div>
                  <el-progress :percentage="systemInfo.disk" :color="getDiskColor(systemInfo.disk)" />
                </div>
              </div>
            </el-col>
            <el-col :xs="24" :sm="12" :md="6" :lg="6" :xl="6">
              <div class="stat-item">
                <div class="stat-icon network">
                  <el-icon><upload /></el-icon>
                </div>
                <div class="stat-info">
                  <div class="stat-title">网络流量</div>
                  <div class="stat-value">{{ formatNetworkSpeed(systemInfo.network) }}</div>
                  <div class="stat-subtitle">↑ {{ formatNetworkSpeed(systemInfo.networkUp) }} | ↓ {{ formatNetworkSpeed(systemInfo.networkDown) }}</div>
                </div>
              </div>
            </el-col>
          </el-row>
        </el-card>
      </el-col>

      <!-- CPU 使用率图表 -->
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card class="chart-card">
          <template #header>
            <div class="card-header">
              <h3>CPU 使用率</h3>
            </div>
          </template>
          <div class="chart-container" ref="cpuChartRef"></div>
        </el-card>
      </el-col>

      <!-- 内存使用率图表 -->
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card class="chart-card">
          <template #header>
            <div class="card-header">
              <h3>内存使用率</h3>
            </div>
          </template>
          <div class="chart-container" ref="memoryChartRef"></div>
        </el-card>
      </el-col>

      <!-- 磁盘使用情况 -->
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card class="chart-card">
          <template #header>
            <div class="card-header">
              <h3>磁盘使用情况</h3>
            </div>
          </template>
          <div class="chart-container" ref="diskChartRef"></div>
        </el-card>
      </el-col>

      <!-- 网络流量图表 -->
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card class="chart-card">
          <template #header>
            <div class="card-header">
              <h3>网络流量</h3>
            </div>
          </template>
          <div class="chart-container" ref="networkChartRef"></div>
        </el-card>
      </el-col>

      <!-- 系统信息 -->
      <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="24">
        <el-card>
          <template #header>
            <div class="card-header">
              <h3>系统信息</h3>
            </div>
          </template>
          <el-descriptions :column="2" border>
            <el-descriptions-item label="操作系统">{{ systemInfo.os }}</el-descriptions-item>
            <el-descriptions-item label="内核版本">{{ systemInfo.kernel }}</el-descriptions-item>
            <el-descriptions-item label="主机名">{{ systemInfo.hostname }}</el-descriptions-item>
            <el-descriptions-item label="IP地址">{{ systemInfo.ip }}</el-descriptions-item>
            <el-descriptions-item label="运行时间">{{ systemInfo.uptime }}</el-descriptions-item>
            <el-descriptions-item label="负载均衡">{{ systemInfo.load }}</el-descriptions-item>
          </el-descriptions>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { Connection, Upload, Document } from '@element-plus/icons-vue'
import * as echarts from 'echarts'

// 模拟系统信息数据
const systemInfo = ref({
  cpu: 45,
  memory: 60,
  disk: 75,
  network: 5 * 1024 * 1024, // 5MB/s
  networkUp: 1.2 * 1024 * 1024, // 1.2MB/s
  networkDown: 3.8 * 1024 * 1024, // 3.8MB/s
  os: 'CentOS 8.4',
  kernel: '5.4.17-2102.201.3.el8.x86_64',
  hostname: 'feijige-server',
  ip: '192.168.1.100',
  uptime: '10天 5小时 30分钟',
  load: '0.52, 0.58, 0.60'
})

// 图表引用
const cpuChartRef = ref(null)
const memoryChartRef = ref(null)
const diskChartRef = ref(null)
const networkChartRef = ref(null)

// 图表实例
let cpuChart = null
let memoryChart = null
let diskChart = null
let networkChart = null

// 刷新数据
const refreshData = () => {
  // 模拟数据刷新
  systemInfo.value.cpu = Math.floor(Math.random() * 100)
  systemInfo.value.memory = Math.floor(Math.random() * 100)
  systemInfo.value.disk = Math.floor(Math.random() * 100)
  systemInfo.value.network = Math.random() * 10 * 1024 * 1024
  systemInfo.value.networkUp = Math.random() * 3 * 1024 * 1024
  systemInfo.value.networkDown = Math.random() * 7 * 1024 * 1024
  
  // 更新图表
  updateCharts()
}

// 格式化网络速度
const formatNetworkSpeed = (bytes) => {
  if (bytes < 1024) {
    return bytes.toFixed(2) + ' B/s'
  } else if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(2) + ' KB/s'
  } else if (bytes < 1024 * 1024 * 1024) {
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB/s'
  } else {
    return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB/s'
  }
}

// 获取CPU颜色
const getCpuColor = (value) => {
  if (value < 60) return '#67C23A'
  if (value < 80) return '#E6A23C'
  return '#F56C6C'
}

// 获取内存颜色
const getMemoryColor = (value) => {
  if (value < 70) return '#67C23A'
  if (value < 85) return '#E6A23C'
  return '#F56C6C'
}

// 获取磁盘颜色
const getDiskColor = (value) => {
  if (value < 80) return '#67C23A'
  if (value < 90) return '#E6A23C'
  return '#F56C6C'
}

// 初始化图表
const initCharts = () => {
  // CPU图表
  cpuChart = echarts.init(cpuChartRef.value)
  cpuChart.setOption({
    title: { text: '' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: Array.from({ length: 20 }, (_, i) => i)
    },
    yAxis: {
      type: 'value',
      min: 0,
      max: 100,
      name: '%'
    },
    series: [{
      data: Array.from({ length: 20 }, () => Math.floor(Math.random() * 100)),
      type: 'line',
      smooth: true,
      areaStyle: {}
    }]
  })

  // 内存图表
  memoryChart = echarts.init(memoryChartRef.value)
  memoryChart.setOption({
    title: { text: '' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: Array.from({ length: 20 }, (_, i) => i)
    },
    yAxis: {
      type: 'value',
      min: 0,
      max: 100,
      name: '%'
    },
    series: [{
      data: Array.from({ length: 20 }, () => Math.floor(Math.random() * 100)),
      type: 'line',
      smooth: true,
      areaStyle: {}
    }]
  })

  // 磁盘图表
  diskChart = echarts.init(diskChartRef.value)
  diskChart.setOption({
    title: { text: '' },
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
      orient: 'vertical',
      left: 10,
      data: ['已使用', '可用空间']
    },
    series: [
      {
        name: '磁盘空间',
        type: 'pie',
        radius: ['50%', '70%'],
        avoidLabelOverlap: false,
        label: {
          show: false,
          position: 'center'
        },
        emphasis: {
          label: {
            show: true,
            fontSize: '18',
            fontWeight: 'bold'
          }
        },
        labelLine: {
          show: false
        },
        data: [
          { value: systemInfo.value.disk, name: '已使用' },
          { value: 100 - systemInfo.value.disk, name: '可用空间' }
        ]
      }
    ]
  })

  // 网络图表
  networkChart = echarts.init(networkChartRef.value)
  networkChart.setOption({
    title: { text: '' },
    tooltip: { trigger: 'axis' },
    legend: {
      data: ['上传', '下载']
    },
    xAxis: {
      type: 'category',
      data: Array.from({ length: 20 }, (_, i) => i)
    },
    yAxis: {
      type: 'value',
      name: 'MB/s'
    },
    series: [
      {
        name: '上传',
        type: 'line',
        data: Array.from({ length: 20 }, () => (Math.random() * 3).toFixed(2))
      },
      {
        name: '下载',
        type: 'line',
        data: Array.from({ length: 20 }, () => (Math.random() * 7).toFixed(2))
      }
    ]
  })
}

// 更新图表
const updateCharts = () => {
  if (!cpuChart || !memoryChart || !diskChart || !networkChart) return

  // 更新CPU图表
  const cpuOption = cpuChart.getOption()
  cpuOption.series[0].data.shift()
  cpuOption.series[0].data.push(systemInfo.value.cpu)
  cpuChart.setOption(cpuOption)

  // 更新内存图表
  const memoryOption = memoryChart.getOption()
  memoryOption.series[0].data.shift()
  memoryOption.series[0].data.push(systemInfo.value.memory)
  memoryChart.setOption(memoryOption)

  // 更新磁盘图表
  diskChart.setOption({
    series: [
      {
        data: [
          { value: systemInfo.value.disk, name: '已使用' },
          { value: 100 - systemInfo.value.disk, name: '可用空间' }
        ]
      }
    ]
  })

  // 更新网络图表
  const networkOption = networkChart.getOption()
  networkOption.series[0].data.shift()
  networkOption.series[0].data.push((systemInfo.value.networkUp / (1024 * 1024)).toFixed(2))
  networkOption.series[1].data.shift()
  networkOption.series[1].data.push((systemInfo.value.networkDown / (1024 * 1024)).toFixed(2))
  networkChart.setOption(networkOption)
}

// 定时刷新数据
let timer = null

onMounted(() => {
  // 初始化图表
  initCharts()
  
  // 设置定时刷新
  timer = setInterval(() => {
    refreshData()
  }, 5000)
  
  // 监听窗口大小变化，调整图表大小
  window.addEventListener('resize', () => {
    cpuChart && cpuChart.resize()
    memoryChart && memoryChart.resize()
    diskChart && diskChart.resize()
    networkChart && networkChart.resize()
  })
})

onUnmounted(() => {
  // 清除定时器
  if (timer) {
    clearInterval(timer)
  }
  
  // 销毁图表实例
  cpuChart && cpuChart.dispose()
  memoryChart && memoryChart.dispose()
  diskChart && diskChart.dispose()
  networkChart && networkChart.dispose()
  
  // 移除事件监听
  window.removeEventListener('resize', () => {})
})
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}

.el-row {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.overview-card {
  margin-bottom: 20px;
}

.stat-item {
  display: flex;
  align-items: center;
  padding: 10px 0;
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 15px;
  font-size: 24px;
  color: #fff;
}

.stat-icon.cpu {
  background-color: #409EFF;
}

.stat-icon.memory {
  background-color: #67C23A;
}

.stat-icon.disk {
  background-color: #E6A23C;
}

.stat-icon.network {
  background-color: #F56C6C;
}

.stat-info {
  flex: 1;
}

.stat-title {
  font-size: 14px;
  color: #606266;
  margin-bottom: 5px;
}

.stat-value {
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 5px;
}

.stat-subtitle {
  font-size: 12px;
  color: #909399;
}

.chart-card {
  margin-bottom: 20px;
}

.chart-container {
  height: 300px;
}
</style>