<template>
  <div class="websites-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <h3>网站管理</h3>
          <div class="header-actions">
            <el-input
              v-model="searchQuery"
              placeholder="搜索网站"
              prefix-icon="Search"
              clearable
              class="search-input"
            />
            <el-button type="primary" @click="refreshWebsites">刷新</el-button>
            <el-button type="success" @click="createWebsite">创建网站</el-button>
          </div>
        </div>
      </template>

      <el-table
        :data="filteredWebsites"
        style="width: 100%"
        v-loading="loading"
        border
        stripe
      >
        <el-table-column prop="name" label="网站名称" min-width="180" sortable>
          <template #default="{ row }">
            <div class="website-info">
              <el-avatar :size="32" :src="row.icon || defaultIcon" class="website-icon" />
              <div>
                <div class="website-name">{{ row.name }}</div>
                <div class="website-domain">{{ row.domain }}</div>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="type" label="类型" width="120" sortable>
          <template #default="{ row }">
            <el-tag>{{ row.type }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100" sortable>
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="php" label="PHP版本" width="120" sortable />
        <el-table-column prop="path" label="网站目录" min-width="200" show-overflow-tooltip />
        <el-table-column prop="traffic" label="今日流量" width="120" sortable>
          <template #default="{ row }">
            {{ formatTraffic(row.traffic) }}
          </template>
        </el-table-column>
        <el-table-column prop="ssl" label="SSL" width="100" sortable>
          <template #default="{ row }">
            <el-switch
              v-model="row.ssl"
              @change="toggleSSL(row)"
              :active-text="'已启用'"
              :inactive-text="'未启用'"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="320" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="访问网站" placement="top">
                <el-button size="small" type="primary" @click="visitWebsite(row)">
                  <el-icon><Link /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="文件管理" placement="top">
                <el-button size="small" type="primary" @click="manageFiles(row)">
                  <el-icon><Folder /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="数据库" placement="top">
                <el-button size="small" type="primary" @click="manageDatabase(row)">
                  <el-icon><DataBase /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="设置" placement="top">
                <el-button size="small" type="info" @click="editWebsite(row)">
                  <el-icon><Setting /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="备份" placement="top">
                <el-button size="small" type="warning" @click="backupWebsite(row)">
                  <el-icon><Download /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="删除" placement="top">
                <el-button size="small" type="danger" @click="deleteWebsite(row)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="filteredWebsites.length"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 网站详情对话框 -->
    <el-dialog
      v-model="websiteDetailsVisible"
      :title="dialogTitle"
      width="60%"
      destroy-on-close
    >
      <el-form
        ref="websiteForm"
        :model="websiteForm"
        label-width="120px"
        :rules="formRules"
      >
        <el-form-item label="网站名称" prop="name">
          <el-input v-model="websiteForm.name" />
        </el-form-item>
        <el-form-item label="域名" prop="domain">
          <el-input v-model="websiteForm.domain" />
        </el-form-item>
        <el-form-item label="网站类型" prop="type">
          <el-select v-model="websiteForm.type" placeholder="选择网站类型" style="width: 100%">
            <el-option label="PHP" value="PHP" />
            <el-option label="Node.js" value="Node.js" />
            <el-option label="Python" value="Python" />
            <el-option label="静态网站" value="Static" />
          </el-select>
        </el-form-item>
        <el-form-item label="PHP版本" prop="php" v-if="websiteForm.type === 'PHP'">
          <el-select v-model="websiteForm.php" placeholder="选择PHP版本" style="width: 100%">
            <el-option label="PHP 8.2" value="8.2" />
            <el-option label="PHP 8.1" value="8.1" />
            <el-option label="PHP 8.0" value="8.0" />
            <el-option label="PHP 7.4" value="7.4" />
            <el-option label="PHP 7.3" value="7.3" />
          </el-select>
        </el-form-item>
        <el-form-item label="网站目录" prop="path">
          <el-input v-model="websiteForm.path" />
        </el-form-item>
        <el-form-item label="SSL证书" prop="ssl">
          <el-switch v-model="websiteForm.ssl" />
        </el-form-item>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="websiteDetailsVisible = false">取消</el-button>
          <el-button type="primary" @click="saveWebsite">保存</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 确认对话框 -->
    <el-dialog
      v-model="confirmDialogVisible"
      title="确认操作"
      width="30%"
    >
      <span>{{ confirmMessage }}</span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="confirmDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmAction">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Link, Folder, DataBase, Setting, Download, Delete, Search } from '@element-plus/icons-vue'

const router = useRouter()
const defaultIcon = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg'

// 网站列表数据
const websites = ref([])
const loading = ref(true)
const searchQuery = ref('')
const currentPage = ref(1)
const pageSize = ref(10)

// 网站详情对话框
const websiteDetailsVisible = ref(false)
const dialogTitle = ref('编辑网站')
const websiteForm = ref({
  id: null,
  name: '',
  domain: '',
  type: 'PHP',
  php: '8.1',
  path: '',
  ssl: false,
  status: '运行中',
  traffic: 0
})

// 表单验证规则
const formRules = {
  name: [{ required: true, message: '请输入网站名称', trigger: 'blur' }],
  domain: [{ required: true, message: '请输入域名', trigger: 'blur' }],
  type: [{ required: true, message: '请选择网站类型', trigger: 'change' }],
  path: [{ required: true, message: '请输入网站目录', trigger: 'blur' }]
}

// 确认对话框
const confirmDialogVisible = ref(false)
const confirmMessage = ref('')
const pendingAction = ref(null)

// 过滤后的网站列表
const filteredWebsites = computed(() => {
  if (!searchQuery.value) {
    return websites.value
  }
  
  const query = searchQuery.value.toLowerCase()
  return websites.value.filter(website => {
    return website.name.toLowerCase().includes(query) ||
           website.domain.toLowerCase().includes(query) ||
           website.type.toLowerCase().includes(query) ||
           website.path.toLowerCase().includes(query)
  })
})

// 获取状态类型
const getStatusType = (status) => {
  const statusMap = {
    '运行中': 'success',
    '已停止': 'danger',
    '维护中': 'warning',
    '构建中': 'info'
  }
  return statusMap[status] || ''
}

// 格式化流量
const formatTraffic = (bytes) => {
  if (bytes < 1024) {
    return bytes + ' B'
  } else if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(2) + ' KB'
  } else if (bytes < 1024 * 1024 * 1024) {
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB'
  } else {
    return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
  }
}

// 刷新网站列表
const refreshWebsites = async () => {
  loading.value = true
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // 生成模拟数据
    const statuses = ['运行中', '已停止', '维护中', '构建中']
    const types = ['PHP', 'Node.js', 'Python', 'Static']
    const phpVersions = ['7.3', '7.4', '8.0', '8.1', '8.2']
    const domains = [
      'example.com', 'mywebsite.org', 'blog.example.com', 'shop.example.com',
      'api.example.com', 'admin.example.com', 'test.example.com', 'dev.example.com'
    ]
    
    const mockWebsites = Array.from({ length: 20 }, (_, i) => {
      const name = `网站${i + 1}`
      const domain = domains[Math.floor(Math.random() * domains.length)]
      const type = types[Math.floor(Math.random() * types.length)]
      const status = statuses[Math.floor(Math.random() * statuses.length)]
      const php = phpVersions[Math.floor(Math.random() * phpVersions.length)]
      const path = `/var/www/${domain}`
      const traffic = Math.floor(Math.random() * 1024 * 1024 * 1024)
      const ssl = Math.random() > 0.5
      
      return {
        id: i + 1,
        name,
        domain,
        type,
        status,
        php,
        path,
        traffic,
        ssl,
        icon: null
      }
    })
    
    websites.value = mockWebsites
  } catch (error) {
    console.error('Failed to fetch websites:', error)
    ElMessage.error('获取网站列表失败')
  } finally {
    loading.value = false
  }
}

// 创建网站
const createWebsite = () => {
  dialogTitle.value = '创建网站'
  websiteForm.value = {
    id: null,
    name: '',
    domain: '',
    type: 'PHP',
    php: '8.1',
    path: '',
    ssl: false,
    status: '运行中',
    traffic: 0
  }
  websiteDetailsVisible.value = true
}

// 编辑网站
const editWebsite = (website) => {
  dialogTitle.value = '编辑网站'
  websiteForm.value = { ...website }
  websiteDetailsVisible.value = true
}

// 保存网站
const saveWebsite = async () => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    if (websiteForm.value.id) {
      // 更新现有网站
      const index = websites.value.findIndex(w => w.id === websiteForm.value.id)
      if (index !== -1) {
        websites.value[index] = { ...websiteForm.value }
        ElMessage.success('网站更新成功')
      }
    } else {
      // 创建新网站
      const newId = Math.max(...websites.value.map(w => w.id), 0) + 1
      websites.value.push({
        ...websiteForm.value,
        id: newId,
        traffic: 0
      })
      ElMessage.success('网站创建成功')
    }
    
    websiteDetailsVisible.value = false
  } catch (error) {
    console.error('Failed to save website:', error)
    ElMessage.error('保存网站失败')
  }
}

// 访问网站
const visitWebsite = (website) => {
  const url = website.ssl ? `https://${website.domain}` : `http://${website.domain}`
  window.open(url, '_blank')
}

// 管理文件
const manageFiles = (website) => {
  ElMessage.info(`打开文件管理器: ${website.path}`)
  // 实际应用中应该跳转到文件管理页面
  // router.push(`/file-manager?path=${encodeURIComponent(website.path)}`)
}

// 管理数据库
const manageDatabase = (website) => {
  ElMessage.info(`打开数据库管理: ${website.name}`)
  // 实际应用中应该跳转到数据库管理页面
  // router.push(`/database-manager?website=${website.id}`)
}

// 备份网站
const backupWebsite = (website) => {
  confirmMessage.value = `确定要备份网站 ${website.name} 吗？`
  pendingAction.value = () => {
    // 模拟API请求
    ElMessage.success(`已开始备份网站 ${website.name}`)
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 删除网站
const deleteWebsite = (website) => {
  confirmMessage.value = `确定要删除网站 ${website.name} 吗？此操作不可恢复！`
  pendingAction.value = () => {
    // 模拟API请求
    websites.value = websites.value.filter(w => w.id !== website.id)
    ElMessage.success(`已删除网站 ${website.name}`)
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 切换SSL状态
const toggleSSL = async (website) => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    ElMessage.success(`${website.ssl ? '启用' : '禁用'} SSL 成功: ${website.domain}`)
  } catch (error) {
    // 恢复原状态
    website.ssl = !website.ssl
    ElMessage.error('SSL设置失败')
  }
}

// 确认操作
const confirmAction = () => {
  if (pendingAction.value) {
    pendingAction.value()
  }
}

// 分页处理
const handleSizeChange = (size) => {
  pageSize.value = size
}

const handleCurrentChange = (page) => {
  currentPage.value = page
}

onMounted(() => {
  // 初始加载
  refreshWebsites()
})
</script>

<style scoped>
.websites-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.search-input {
  width: 250px;
}

.website-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.website-icon {
  flex-shrink: 0;
}

.website-name {
  font-weight: bold;
}

.website-domain {
  font-size: 12px;
  color: #909399;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
</style>