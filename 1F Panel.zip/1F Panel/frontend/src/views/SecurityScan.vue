<template>
  <div class="security-scan-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <h3>安全扫描</h3>
          <div class="header-actions">
            <el-button type="primary" @click="startScan">开始扫描</el-button>
            <el-button type="success" @click="showScanHistory">扫描历史</el-button>
          </div>
        </div>
      </template>

      <el-tabs v-model="activeTab">
        <el-tab-pane label="漏洞扫描" name="vulnerability">
          <div class="scan-options">
            <el-form :model="scanOptions" label-width="120px">
              <el-form-item label="扫描范围">
                <el-radio-group v-model="scanOptions.scanScope">
                  <el-radio label="full">完整扫描</el-radio>
                  <el-radio label="quick">快速扫描</el-radio>
                  <el-radio label="custom">自定义</el-radio>
                </el-radio-group>
              </el-form-item>
              
              <el-form-item label="扫描目标" v-if="scanOptions.scanScope === 'custom'">
                <el-select
                  v-model="scanOptions.targets"
                  multiple
                  collapse-tags
                  collapse-tags-tooltip
                  placeholder="选择扫描目标"
                  style="width: 100%"
                >
                  <el-option
                    v-for="item in targetOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
              
              <el-form-item label="扫描深度">
                <el-slider
                  v-model="scanOptions.scanDepth"
                  :min="1"
                  :max="5"
                  :marks="{
                    1: '基础',
                    3: '标准',
                    5: '深度'
                  }"
                />
              </el-form-item>
              
              <el-form-item label="自动修复">
                <el-switch v-model="scanOptions.autoFix" />
                <div class="form-item-description">启用后，系统将尝试自动修复发现的低风险漏洞</div>
              </el-form-item>
              
              <el-form-item label="扫描计划">
                <el-select v-model="scanOptions.schedule" placeholder="选择扫描计划" style="width: 100%">
                  <el-option label="单次扫描" value="once" />
                  <el-option label="每日扫描" value="daily" />
                  <el-option label="每周扫描" value="weekly" />
                  <el-option label="每月扫描" value="monthly" />
                </el-select>
              </el-form-item>
            </el-form>
          </div>
        </el-tab-pane>
        
        <el-tab-pane label="恶意软件检测" name="malware">
          <div class="scan-options">
            <el-form :model="malwareOptions" label-width="120px">
              <el-form-item label="检测目录">
                <el-input v-model="malwareOptions.directory" placeholder="/var/www/html" />
              </el-form-item>
              
              <el-form-item label="文件类型">
                <el-select
                  v-model="malwareOptions.fileTypes"
                  multiple
                  collapse-tags
                  collapse-tags-tooltip
                  placeholder="选择文件类型"
                  style="width: 100%"
                >
                  <el-option label="PHP文件" value=".php" />
                  <el-option label="JavaScript文件" value=".js" />
                  <el-option label="HTML文件" value=".html" />
                  <el-option label="所有文件" value="all" />
                </el-select>
              </el-form-item>
              
              <el-form-item label="检测级别">
                <el-radio-group v-model="malwareOptions.level">
                  <el-radio label="basic">基础检测</el-radio>
                  <el-radio label="advanced">高级检测</el-radio>
                  <el-radio label="heuristic">启发式检测</el-radio>
                </el-radio-group>
              </el-form-item>
              
              <el-form-item label="隔离检测">
                <el-switch v-model="malwareOptions.quarantine" />
                <div class="form-item-description">启用后，检测到的恶意文件将被隔离</div>
              </el-form-item>
            </el-form>
          </div>
        </el-tab-pane>
        
        <el-tab-pane label="防火墙审计" name="firewall">
          <div class="scan-options">
            <el-form :model="firewallOptions" label-width="120px">
              <el-form-item label="审计类型">
                <el-checkbox-group v-model="firewallOptions.auditTypes">
                  <el-checkbox label="rules">规则审计</el-checkbox>
                  <el-checkbox label="ports">端口审计</el-checkbox>
                  <el-checkbox label="services">服务审计</el-checkbox>
                  <el-checkbox label="logs">日志审计</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              
              <el-form-item label="安全基线">
                <el-select v-model="firewallOptions.baseline" placeholder="选择安全基线" style="width: 100%">
                  <el-option label="标准安全基线" value="standard" />
                  <el-option label="CIS基线" value="cis" />
                  <el-option label="NIST基线" value="nist" />
                  <el-option label="自定义基线" value="custom" />
                </el-select>
              </el-form-item>
            </el-form>
          </div>
        </el-tab-pane>
      </el-tabs>

      <!-- 扫描结果区域 -->
      <div v-if="scanResults.length > 0" class="scan-results">
        <el-divider>扫描结果</el-divider>
        
        <div class="result-summary">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-statistic title="高危漏洞" :value="getVulnerabilityCount('high')">
                <template #value>
                  <div class="statistic-content danger">
                    {{ getVulnerabilityCount('high') }}
                  </div>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="中危漏洞" :value="getVulnerabilityCount('medium')">
                <template #value>
                  <div class="statistic-content warning">
                    {{ getVulnerabilityCount('medium') }}
                  </div>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="低危漏洞" :value="getVulnerabilityCount('low')">
                <template #value>
                  <div class="statistic-content info">
                    {{ getVulnerabilityCount('low') }}
                  </div>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="扫描时间" :value="scanTime">
                <template #value>
                  <div class="statistic-content">
                    {{ scanTime }}
                  </div>
                </template>
              </el-statistic>
            </el-col>
          </el-row>
        </div>
        
        <el-table
          :data="scanResults"
          style="width: 100%"
          border
          stripe
        >
          <el-table-column prop="type" label="类型" width="120">
            <template #default="{ row }">
              <el-tag :type="getTypeTagType(row.type)">{{ row.type }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="severity" label="风险等级" width="120">
            <template #default="{ row }">
              <el-tag :type="getSeverityTagType(row.severity)">{{ row.severity }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="title" label="漏洞标题" min-width="200" />
          <el-table-column prop="location" label="位置" min-width="200" />
          <el-table-column prop="status" label="状态" width="120">
            <template #default="{ row }">
              <el-tag :type="getStatusTagType(row.status)">{{ row.status }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="200" fixed="right">
            <template #default="{ row }">
              <el-button-group>
                <el-tooltip content="详情" placement="top">
                  <el-button size="small" type="primary" @click="viewVulnerabilityDetails(row)">
                    <el-icon><View /></el-icon>
                  </el-button>
                </el-tooltip>
                <el-tooltip content="修复" placement="top">
                  <el-button size="small" type="success" @click="fixVulnerability(row)">
                    <el-icon><Check /></el-icon>
                  </el-button>
                </el-tooltip>
                <el-tooltip content="忽略" placement="top">
                  <el-button size="small" type="info" @click="ignoreVulnerability(row)">
                    <el-icon><Close /></el-icon>
                  </el-button>
                </el-tooltip>
              </el-button-group>
            </template>
          </el-table-column>
        </el-table>
      </div>
      
      <!-- 扫描进度 -->
      <div v-if="scanning" class="scan-progress">
        <el-progress 
          :percentage="scanProgress" 
          :status="scanProgress < 100 ? '' : 'success'"
          :stroke-width="20"
        >
          <template #default="{ percentage }">
            <span class="progress-text">{{ scanProgressText }}</span>
          </template>
        </el-progress>
      </div>
    </el-card>

    <!-- 漏洞详情对话框 -->
    <el-dialog
      v-model="vulnerabilityDetailsVisible"
      title="漏洞详情"
      width="70%"
    >
      <el-descriptions :column="2" border>
        <el-descriptions-item label="漏洞标题">{{ selectedVulnerability.title }}</el-descriptions-item>
        <el-descriptions-item label="风险等级">
          <el-tag :type="getSeverityTagType(selectedVulnerability.severity)">{{ selectedVulnerability.severity }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="漏洞类型">{{ selectedVulnerability.type }}</el-descriptions-item>
        <el-descriptions-item label="发现时间">{{ selectedVulnerability.discoveredAt }}</el-descriptions-item>
        <el-descriptions-item label="位置" :span="2">{{ selectedVulnerability.location }}</el-descriptions-item>
        <el-descriptions-item label="漏洞描述" :span="2">{{ selectedVulnerability.description }}</el-descriptions-item>
      </el-descriptions>

      <el-divider>修复建议</el-divider>
      <div class="vulnerability-solution">
        <p>{{ selectedVulnerability.solution }}</p>
      </div>

      <el-divider>受影响的代码</el-divider>
      <el-input
        v-model="selectedVulnerability.affectedCode"
        type="textarea"
        :rows="10"
        readonly
      />
    </el-dialog>

    <!-- 扫描历史对话框 -->
    <el-dialog
      v-model="scanHistoryVisible"
      title="扫描历史"
      width="80%"
    >
      <el-table
        :data="scanHistoryList"
        style="width: 100%"
        border
        stripe
      >
        <el-table-column prop="date" label="扫描日期" width="180" sortable />
        <el-table-column prop="type" label="扫描类型" width="150" />
        <el-table-column prop="duration" label="扫描时长" width="120" />
        <el-table-column label="漏洞统计" width="300">
          <template #default="{ row }">
            <el-tag type="danger" class="mx-1">高危: {{ row.highCount }}</el-tag>
            <el-tag type="warning" class="mx-1">中危: {{ row.mediumCount }}</el-tag>
            <el-tag type="info" class="mx-1">低危: {{ row.lowCount }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="row.status === '已完成' ? 'success' : 'warning'">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="查看报告" placement="top">
                <el-button size="small" type="primary" @click="viewScanReport(row)">
                  <el-icon><Document /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="下载报告" placement="top">
                <el-button size="small" type="success" @click="downloadScanReport(row)">
                  <el-icon><Download /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { View, Check, Close, Download, Document } from '@element-plus/icons-vue'

// 扫描选项
const activeTab = ref('vulnerability')
const scanOptions = ref({
  scanScope: 'quick',
  targets: [],
  scanDepth: 3,
  autoFix: false,
  schedule: 'once'
})

const malwareOptions = ref({
  directory: '/var/www/html',
  fileTypes: ['.php', '.js'],
  level: 'advanced',
  quarantine: true
})

const firewallOptions = ref({
  auditTypes: ['rules', 'ports'],
  baseline: 'standard'
})

// 扫描目标选项
const targetOptions = ref([
  { label: '系统文件', value: 'system' },
  { label: '网站文件', value: 'websites' },
  { label: '数据库', value: 'databases' },
  { label: '配置文件', value: 'configs' },
  { label: '用户目录', value: 'home' }
])

// 扫描状态
const scanning = ref(false)
const scanProgress = ref(0)
const scanProgressText = ref('准备扫描...')
const scanTime = ref('--')

// 扫描结果
const scanResults = ref([])
const selectedVulnerability = ref({})
const vulnerabilityDetailsVisible = ref(false)

// 扫描历史
const scanHistoryList = ref([])
const scanHistoryVisible = ref(false)

// 开始扫描
const startScan = async () => {
  scanning.value = true
  scanProgress.value = 0
  scanResults.value = []
  scanProgressText.value = '准备扫描...'
  
  // 模拟扫描进度
  const interval = setInterval(() => {
    if (scanProgress.value < 99) {
      scanProgress.value += Math.floor(Math.random() * 5) + 1
      updateScanProgressText()
    } else {
      clearInterval(interval)
      finishScan()
    }
  }, 500)
}

// 更新扫描进度文本
const updateScanProgressText = () => {
  if (scanProgress.value < 20) {
    scanProgressText.value = '正在初始化扫描环境...'
  } else if (scanProgress.value < 40) {
    scanProgressText.value = '正在扫描系统漏洞...'
  } else if (scanProgress.value < 60) {
    scanProgressText.value = '正在检测恶意软件...'
  } else if (scanProgress.value < 80) {
    scanProgressText.value = '正在审计防火墙规则...'
  } else {
    scanProgressText.value = '正在生成报告...'
  }
}

// 完成扫描
const finishScan = () => {
  scanProgress.value = 100
  scanProgressText.value = '扫描完成'
  
  // 设置扫描时间
  const now = new Date()
  scanTime.value = now.toLocaleString()
  
  // 生成模拟扫描结果
  generateMockResults()
  
  // 添加到扫描历史
  addToScanHistory()
  
  // 延迟后隐藏进度条
  setTimeout(() => {
    scanning.value = false
  }, 2000)
}

// 生成模拟扫描结果
const generateMockResults = () => {
  const vulnerabilityTypes = ['SQL注入', 'XSS漏洞', '文件包含', '权限提升', '配置错误', '弱密码']
  const severityLevels = ['高危', '中危', '低危']
  const statusOptions = ['未修复', '已修复', '已忽略']
  const locations = [
    '/var/www/html/index.php',
    '/etc/nginx/nginx.conf',
    '/var/www/html/admin/login.php',
    '/home/user/.ssh/config',
    '/var/www/html/api/users.php'
  ]
  
  // 生成随机数量的漏洞
  const resultCount = Math.floor(Math.random() * 15) + 5
  const mockResults = []
  
  for (let i = 0; i < resultCount; i++) {
    const type = vulnerabilityTypes[Math.floor(Math.random() * vulnerabilityTypes.length)]
    const severity = severityLevels[Math.floor(Math.random() * severityLevels.length)]
    const status = statusOptions[Math.floor(Math.random() * statusOptions.length)]
    const location = locations[Math.floor(Math.random() * locations.length)]
    
    mockResults.push({
      id: i + 1,
      type,
      severity,
      title: `${type}漏洞 #${i + 1}`,
      location,
      status,
      discoveredAt: new Date().toLocaleString(),
      description: `这是一个${severity}的${type}漏洞，可能导致系统安全风险。建议尽快修复。`,
      solution: `修复此${type}漏洞，您需要更新相关代码，增加输入验证和过滤，确保所有用户输入都经过适当的安全处理。`,
      affectedCode: `function processUserInput($input) {\n  $query = "SELECT * FROM users WHERE username = '" . $input . "'";
  $result = mysqli_query($conn, $query);\n  return $result;\n}`
    })
  }
  
  scanResults.value = mockResults
}

// 添加到扫描历史
const addToScanHistory = () => {
  const highCount = getVulnerabilityCount('高危')
  const mediumCount = getVulnerabilityCount('中危')
  const lowCount = getVulnerabilityCount('低危')
  
  scanHistoryList.value.unshift({
    id: scanHistoryList.value.length + 1,
    date: new Date().toLocaleString(),
    type: activeTab.value === 'vulnerability' ? '漏洞扫描' : 
          activeTab.value === 'malware' ? '恶意软件检测' : '防火墙审计',
    duration: '2分钟',
    highCount,
    mediumCount,
    lowCount,
    status: '已完成'
  })
}

// 获取漏洞数量
const getVulnerabilityCount = (severity) => {
  return scanResults.value.filter(item => item.severity === severity).length
}

// 获取类型标签样式
const getTypeTagType = (type) => {
  const typeMap = {
    'SQL注入': 'danger',
    'XSS漏洞': 'warning',
    '文件包含': 'danger',
    '权限提升': 'danger',
    '配置错误': 'info',
    '弱密码': 'warning'
  }
  return typeMap[type] || 'info'
}

// 获取严重性标签样式
const getSeverityTagType = (severity) => {
  const severityMap = {
    '高危': 'danger',
    '中危': 'warning',
    '低危': 'info'
  }
  return severityMap[severity] || 'info'
}

// 获取状态标签样式
const getStatusTagType = (status) => {
  const statusMap = {
    '未修复': 'danger',
    '已修复': 'success',
    '已忽略': 'info'
  }
  return statusMap[status] || 'info'
}

// 查看漏洞详情
const viewVulnerabilityDetails = (vulnerability) => {
  selectedVulnerability.value = { ...vulnerability }
  vulnerabilityDetailsVisible.value = true
}

// 修复漏洞
const fixVulnerability = (vulnerability) => {
  const index = scanResults.value.findIndex(item => item.id === vulnerability.id)
  if (index !== -1) {
    scanResults.value[index].status = '已修复'
    ElMessage.success(`已修复漏洞: ${vulnerability.title}`)
  }
}

// 忽略漏洞
const ignoreVulnerability = (vulnerability) => {
  const index = scanResults.value.findIndex(item => item.id === vulnerability.id)
  if (index !== -1) {
    scanResults.value[index].status = '已忽略'
    ElMessage.success(`已忽略漏洞: ${vulnerability.title}`)
  }
}

// 显示扫描历史
const showScanHistory = () => {
  // 如果没有历史记录，生成一些模拟数据
  if (scanHistoryList.value.length === 0) {
    generateMockScanHistory()
  }
  scanHistoryVisible.value = true
}

// 生成模拟扫描历史
const generateMockScanHistory = () => {
  const types = ['漏洞扫描', '恶意软件检测', '防火墙审计']
  const durations = ['1分钟', '2分钟', '3分钟', '5分钟']
  
  // 生成过去30天的扫描记录
  for (let i = 0; i < 10; i++) {
    const date = new Date()
    date.setDate(date.getDate() - i)
    
    scanHistoryList.value.push({
      id: i + 1,
      date: date.toLocaleString(),
      type: types[Math.floor(Math.random() * types.length)],
      duration: durations[Math.floor(Math.random() * durations.length)],
      highCount: Math.floor(Math.random() * 5),
      mediumCount: Math.floor(Math.random() * 10),
      lowCount: Math.floor(Math.random() * 15),
      status: '已完成'
    })
  }
}

// 查看扫描报告
const viewScanReport = (report) => {
  ElMessage.success(`查看扫描报告: ${report.date}`)
  // 实际应用中应该打开报告详情页面
}

// 下载扫描报告
const downloadScanReport = (report) => {
  ElMessage.success(`开始下载扫描报告: ${report.date}`)
  // 实际应用中应该触发下载
}

// 初始化
onMounted(() => {
  // 可以在这里加载初始数据
})
</script>

<style scoped>
.security-scan-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.scan-options {
  margin-top: 20px;
  margin-bottom: 20px;
}

.form-item-description {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.scan-progress {
  margin-top: 30px;
  margin-bottom: 30px;
}

.progress-text {
  font-size: 14px;
  font-weight: bold;
}

.scan-results {
  margin-top: 30px;
}

.result-summary {
  margin-bottom: 20px;
}

.statistic-content {
  font-size: 24px;
  font-weight: bold;
}

.statistic-content.danger {
  color: #f56c6c;
}

.statistic-content.warning {
  color: #e6a23c;
}

.statistic-content.info {
  color: #909399;
}

.vulnerability-solution {
  background-color: #f8f8f8;
  padding: 15px;
  border-radius: 4px;
  margin-bottom: 20px;
}

.mx-1 {
  margin-left: 5px;
  margin-right: 5px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>