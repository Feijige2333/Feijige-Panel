<template>
  <div class="databases-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <h3>数据库管理</h3>
          <div class="header-actions">
            <el-input
              v-model="searchQuery"
              placeholder="搜索数据库"
              prefix-icon="Search"
              clearable
              class="search-input"
            />
            <el-button type="primary" @click="refreshDatabases">刷新</el-button>
            <el-button type="success" @click="createDatabase">创建数据库</el-button>
          </div>
        </div>
      </template>

      <el-table
        :data="filteredDatabases"
        style="width: 100%"
        v-loading="loading"
        border
        stripe
      >
        <el-table-column prop="name" label="数据库名称" min-width="180" sortable />
        <el-table-column prop="type" label="类型" width="120" sortable>
          <template #default="{ row }">
            <el-tag :type="getDbTypeColor(row.type)">{{ row.type }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="size" label="大小" width="120" sortable>
          <template #default="{ row }">
            {{ formatSize(row.size) }}
          </template>
        </el-table-column>
        <el-table-column prop="tables" label="表数量" width="120" sortable />
        <el-table-column prop="charset" label="字符集" width="120" sortable />
        <el-table-column prop="created" label="创建时间" width="180" sortable />
        <el-table-column prop="status" label="状态" width="100" sortable>
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="320" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="管理" placement="top">
                <el-button size="small" type="primary" @click="manageDatabase(row)">
                  <el-icon><Management /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="导入" placement="top">
                <el-button size="small" type="primary" @click="importDatabase(row)">
                  <el-icon><Upload /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="导出" placement="top">
                <el-button size="small" type="primary" @click="exportDatabase(row)">
                  <el-icon><Download /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="备份" placement="top">
                <el-button size="small" type="warning" @click="backupDatabase(row)">
                  <el-icon><CopyDocument /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="设置" placement="top">
                <el-button size="small" type="info" @click="editDatabase(row)">
                  <el-icon><Setting /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="删除" placement="top">
                <el-button size="small" type="danger" @click="deleteDatabase(row)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="filteredDatabases.length"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 数据库详情对话框 -->
    <el-dialog
      v-model="databaseDetailsVisible"
      :title="dialogTitle"
      width="60%"
      destroy-on-close
    >
      <el-form
        ref="databaseForm"
        :model="databaseForm"
        label-width="120px"
        :rules="formRules"
      >
        <el-form-item label="数据库名称" prop="name">
          <el-input v-model="databaseForm.name" :disabled="databaseForm.id !== null" />
        </el-form-item>
        <el-form-item label="数据库类型" prop="type">
          <el-select v-model="databaseForm.type" placeholder="选择数据库类型" style="width: 100%">
            <el-option label="MySQL" value="MySQL" />
            <el-option label="MariaDB" value="MariaDB" />
            <el-option label="PostgreSQL" value="PostgreSQL" />
            <el-option label="MongoDB" value="MongoDB" />
            <el-option label="Redis" value="Redis" />
          </el-select>
        </el-form-item>
        <el-form-item label="字符集" prop="charset" v-if="['MySQL', 'MariaDB', 'PostgreSQL'].includes(databaseForm.type)">
          <el-select v-model="databaseForm.charset" placeholder="选择字符集" style="width: 100%">
            <el-option label="UTF-8" value="utf8mb4" />
            <el-option label="Latin1" value="latin1" />
            <el-option label="GBK" value="gbk" />
          </el-select>
        </el-form-item>
        <el-form-item label="用户名" prop="username">
          <el-input v-model="databaseForm.username" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="databaseForm.password" type="password" show-password />
        </el-form-item>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="databaseDetailsVisible = false">取消</el-button>
          <el-button type="primary" @click="saveDatabase">保存</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 确认对话框 -->
    <el-dialog
      v-model="confirmDialogVisible"
      title="确认操作"
      width="30%"
    >
      <span>{{ confirmMessage }}</span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="confirmDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmAction">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Management, Upload, Download, CopyDocument, Setting, Delete, Search } from '@element-plus/icons-vue'

// 数据库列表数据
const databases = ref([])
const loading = ref(true)
const searchQuery = ref('')
const currentPage = ref(1)
const pageSize = ref(10)

// 数据库详情对话框
const databaseDetailsVisible = ref(false)
const dialogTitle = ref('编辑数据库')
const databaseForm = ref({
  id: null,
  name: '',
  type: 'MySQL',
  charset: 'utf8mb4',
  username: '',
  password: '',
  status: '运行中',
  size: 0,
  tables: 0,
  created: ''
})

// 表单验证规则
const formRules = {
  name: [{ required: true, message: '请输入数据库名称', trigger: 'blur' }],
  type: [{ required: true, message: '请选择数据库类型', trigger: 'change' }],
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
}

// 确认对话框
const confirmDialogVisible = ref(false)
const confirmMessage = ref('')
const pendingAction = ref(null)

// 过滤后的数据库列表
const filteredDatabases = computed(() => {
  if (!searchQuery.value) {
    return databases.value
  }
  
  const query = searchQuery.value.toLowerCase()
  return databases.value.filter(database => {
    return database.name.toLowerCase().includes(query) ||
           database.type.toLowerCase().includes(query) ||
           database.charset.toLowerCase().includes(query)
  })
})

// 获取数据库类型颜色
const getDbTypeColor = (type) => {
  const typeMap = {
    'MySQL': '',
    'MariaDB': 'success',
    'PostgreSQL': 'info',
    'MongoDB': 'warning',
    'Redis': 'danger'
  }
  return typeMap[type] || ''
}

// 获取状态类型
const getStatusType = (status) => {
  const statusMap = {
    '运行中': 'success',
    '已停止': 'danger',
    '维护中': 'warning',
    '备份中': 'info'
  }
  return statusMap[status] || ''
}

// 格式化大小
const formatSize = (bytes) => {
  if (bytes < 1024) {
    return bytes + ' B'
  } else if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(2) + ' KB'
  } else if (bytes < 1024 * 1024 * 1024) {
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB'
  } else {
    return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
  }
}

// 刷新数据库列表
const refreshDatabases = async () => {
  loading.value = true
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // 生成模拟数据
    const statuses = ['运行中', '已停止', '维护中', '备份中']
    const types = ['MySQL', 'MariaDB', 'PostgreSQL', 'MongoDB', 'Redis']
    const charsets = ['utf8mb4', 'latin1', 'gbk']
    
    const mockDatabases = Array.from({ length: 20 }, (_, i) => {
      const name = `db_${i + 1}`
      const type = types[Math.floor(Math.random() * types.length)]
      const status = statuses[Math.floor(Math.random() * statuses.length)]
      const charset = charsets[Math.floor(Math.random() * charsets.length)]
      const size = Math.floor(Math.random() * 1024 * 1024 * 1024)
      const tables = Math.floor(Math.random() * 100)
      
      // 生成随机日期（过去一年内）
      const date = new Date()
      date.setDate(date.getDate() - Math.floor(Math.random() * 365))
      const created = date.toISOString().split('T')[0] + ' ' + date.toTimeString().split(' ')[0]
      
      return {
        id: i + 1,
        name,
        type,
        status,
        charset,
        size,
        tables,
        created,
        username: 'user_' + name
      }
    })
    
    databases.value = mockDatabases
  } catch (error) {
    console.error('Failed to fetch databases:', error)
    ElMessage.error('获取数据库列表失败')
  } finally {
    loading.value = false
  }
}

// 创建数据库
const createDatabase = () => {
  dialogTitle.value = '创建数据库'
  databaseForm.value = {
    id: null,
    name: '',
    type: 'MySQL',
    charset: 'utf8mb4',
    username: '',
    password: '',
    status: '运行中',
    size: 0,
    tables: 0,
    created: new Date().toISOString().split('T')[0] + ' ' + new Date().toTimeString().split(' ')[0]
  }
  databaseDetailsVisible.value = true
}

// 编辑数据库
const editDatabase = (database) => {
  dialogTitle.value = '编辑数据库'
  databaseForm.value = { 
    ...database,
    password: '********' // 密码不应该从服务器返回，这里只是模拟
  }
  databaseDetailsVisible.value = true
}

// 保存数据库
const saveDatabase = async () => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    if (databaseForm.value.id) {
      // 更新现有数据库
      const index = databases.value.findIndex(d => d.id === databaseForm.value.id)
      if (index !== -1) {
        databases.value[index] = { 
          ...databases.value[index],
          ...databaseForm.value,
          // 不更新这些字段
          size: databases.value[index].size,
          tables: databases.value[index].tables,
          created: databases.value[index].created
        }
        ElMessage.success('数据库更新成功')
      }
    } else {
      // 创建新数据库
      const newId = Math.max(...databases.value.map(d => d.id), 0) + 1
      databases.value.push({
        ...databaseForm.value,
        id: newId,
        size: 0,
        tables: 0
      })
      ElMessage.success('数据库创建成功')
    }
    
    databaseDetailsVisible.value = false
  } catch (error) {
    console.error('Failed to save database:', error)
    ElMessage.error('保存数据库失败')
  }
}

// 管理数据库
const manageDatabase = (database) => {
  ElMessage.info(`打开数据库管理界面: ${database.name}`)
  // 实际应用中应该跳转到数据库管理界面
  // router.push(`/database-manager/${database.id}`)
}

// 导入数据库
const importDatabase = (database) => {
  ElMessage.info(`导入数据到数据库: ${database.name}`)
  // 实际应用中应该打开文件选择对话框
}

// 导出数据库
const exportDatabase = (database) => {
  ElMessage.info(`导出数据库: ${database.name}`)
  // 实际应用中应该触发下载
}

// 备份数据库
const backupDatabase = (database) => {
  confirmMessage.value = `确定要备份数据库 ${database.name} 吗？`
  pendingAction.value = () => {
    // 模拟API请求
    ElMessage.success(`已开始备份数据库 ${database.name}`)
    // 更新状态
    const index = databases.value.findIndex(d => d.id === database.id)
    if (index !== -1) {
      databases.value[index].status = '备份中'
    }
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 删除数据库
const deleteDatabase = (database) => {
  confirmMessage.value = `确定要删除数据库 ${database.name} 吗？此操作不可恢复！`
  pendingAction.value = () => {
    // 模拟API请求
    databases.value = databases.value.filter(d => d.id !== database.id)
    ElMessage.success(`已删除数据库 ${database.name}`)
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 确认操作
const confirmAction = () => {
  if (pendingAction.value) {
    pendingAction.value()
  }
}

// 分页处理
const handleSizeChange = (size) => {
  pageSize.value = size
}

const handleCurrentChange = (page) => {
  currentPage.value = page
}

onMounted(() => {
  // 初始加载
  refreshDatabases()
})
</script>

<style scoped>
.databases-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.search-input {
  width: 250px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
</style>