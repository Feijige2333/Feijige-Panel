<template>
  <div class="ssl-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <h3>SSL证书管理</h3>
          <div class="header-actions">
            <el-input
              v-model="searchQuery"
              placeholder="搜索证书"
              prefix-icon="Search"
              clearable
              class="search-input"
            />
            <el-button type="primary" @click="refreshCertificates">刷新</el-button>
            <el-button type="success" @click="createCertificate">添加证书</el-button>
          </div>
        </div>
      </template>

      <el-table
        :data="filteredCertificates"
        style="width: 100%"
        v-loading="loading"
        border
        stripe
      >
        <el-table-column prop="name" label="证书名称" min-width="150" sortable />
        <el-table-column prop="domain" label="域名" min-width="180" sortable />
        <el-table-column prop="issuer" label="颁发机构" width="150" sortable />
        <el-table-column prop="created" label="创建时间" width="180" sortable />
        <el-table-column prop="expiry" label="到期时间" width="180" sortable>
          <template #default="{ row }">
            <el-tag :type="getExpiryTagType(row.expiry)">
              {{ row.expiry }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100" sortable>
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="320" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="查看" placement="top">
                <el-button size="small" type="primary" @click="viewCertificate(row)">
                  <el-icon><View /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="下载" placement="top">
                <el-button size="small" type="primary" @click="downloadCertificate(row)">
                  <el-icon><Download /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="部署" placement="top">
                <el-button size="small" type="success" @click="deployCertificate(row)">
                  <el-icon><Upload /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="续期" placement="top">
                <el-button size="small" type="warning" @click="renewCertificate(row)">
                  <el-icon><RefreshRight /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="编辑" placement="top">
                <el-button size="small" type="info" @click="editCertificate(row)">
                  <el-icon><Edit /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="删除" placement="top">
                <el-button size="small" type="danger" @click="deleteCertificate(row)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="filteredCertificates.length"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 证书详情对话框 -->
    <el-dialog
      v-model="certificateDetailsVisible"
      :title="dialogTitle"
      width="60%"
      destroy-on-close
    >
      <el-form
        ref="certificateForm"
        :model="certificateForm"
        label-width="120px"
        :rules="formRules"
      >
        <el-form-item label="证书名称" prop="name">
          <el-input v-model="certificateForm.name" />
        </el-form-item>
        <el-form-item label="域名" prop="domain">
          <el-input v-model="certificateForm.domain" placeholder="example.com 或 *.example.com" />
        </el-form-item>
        <el-form-item label="证书类型" prop="type">
          <el-radio-group v-model="certificateForm.type">
            <el-radio label="lets_encrypt">Let's Encrypt (免费)</el-radio>
            <el-radio label="custom">自定义证书</el-radio>
          </el-radio-group>
        </el-form-item>

        <template v-if="certificateForm.type === 'custom'">
          <el-form-item label="证书文件" prop="certFile">
            <el-upload
              class="upload-demo"
              action="#"
              :auto-upload="false"
              :limit="1"
              :on-change="handleCertFileChange"
            >
              <template #trigger>
                <el-button type="primary">选择证书文件</el-button>
              </template>
              <template #tip>
                <div class="el-upload__tip">请上传PEM格式的证书文件</div>
              </template>
            </el-upload>
          </el-form-item>
          <el-form-item label="私钥文件" prop="keyFile">
            <el-upload
              class="upload-demo"
              action="#"
              :auto-upload="false"
              :limit="1"
              :on-change="handleKeyFileChange"
            >
              <template #trigger>
                <el-button type="primary">选择私钥文件</el-button>
              </template>
              <template #tip>
                <div class="el-upload__tip">请上传PEM格式的私钥文件</div>
              </template>
            </el-upload>
          </el-form-item>
        </template>

        <template v-else>
          <el-form-item label="邮箱地址" prop="email">
            <el-input v-model="certificateForm.email" placeholder="用于Let's Encrypt通知" />
          </el-form-item>
          <el-form-item label="自动续期">
            <el-switch v-model="certificateForm.autoRenew" />
            <div class="form-item-description">启用后，系统将在证书到期前自动续期</div>
          </el-form-item>
        </template>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="certificateDetailsVisible = false">取消</el-button>
          <el-button type="primary" @click="saveCertificate">保存</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 证书查看对话框 -->
    <el-dialog
      v-model="viewCertificateVisible"
      title="证书详情"
      width="70%"
    >
      <el-descriptions :column="2" border>
        <el-descriptions-item label="证书名称">{{ selectedCertificate.name }}</el-descriptions-item>
        <el-descriptions-item label="域名">{{ selectedCertificate.domain }}</el-descriptions-item>
        <el-descriptions-item label="颁发机构">{{ selectedCertificate.issuer }}</el-descriptions-item>
        <el-descriptions-item label="序列号">{{ selectedCertificate.serialNumber }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{ selectedCertificate.created }}</el-descriptions-item>
        <el-descriptions-item label="到期时间">{{ selectedCertificate.expiry }}</el-descriptions-item>
        <el-descriptions-item label="状态">
          <el-tag :type="getStatusType(selectedCertificate.status)">{{ selectedCertificate.status }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="自动续期">
          <el-tag :type="selectedCertificate.autoRenew ? 'success' : 'info'">
            {{ selectedCertificate.autoRenew ? '是' : '否' }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="算法">{{ selectedCertificate.algorithm }}</el-descriptions-item>
        <el-descriptions-item label="密钥长度">{{ selectedCertificate.keyLength }}</el-descriptions-item>
      </el-descriptions>

      <el-divider>证书内容</el-divider>
      
      <el-tabs v-model="activeCertTab">
        <el-tab-pane label="证书信息" name="info">
          <el-input
            v-model="selectedCertificate.certInfo"
            type="textarea"
            :rows="10"
            readonly
          />
        </el-tab-pane>
        <el-tab-pane label="证书链" name="chain">
          <el-input
            v-model="selectedCertificate.certChain"
            type="textarea"
            :rows="10"
            readonly
          />
        </el-tab-pane>
      </el-tabs>
    </el-dialog>

    <!-- 部署证书对话框 -->
    <el-dialog
      v-model="deployCertificateVisible"
      title="部署证书"
      width="50%"
    >
      <el-form
        ref="deployForm"
        :model="deployForm"
        label-width="120px"
      >
        <el-form-item label="选择网站" prop="website">
          <el-select v-model="deployForm.website" placeholder="选择要部署的网站" style="width: 100%">
            <el-option
              v-for="site in websites"
              :key="site.id"
              :label="site.name"
              :value="site.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="部署方式" prop="deployMethod">
          <el-radio-group v-model="deployForm.deployMethod">
            <el-radio label="nginx">Nginx</el-radio>
            <el-radio label="apache">Apache</el-radio>
            <el-radio label="manual">手动配置</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="强制HTTPS" v-if="deployForm.deployMethod !== 'manual'">
          <el-switch v-model="deployForm.forceHttps" />
          <div class="form-item-description">启用后，将自动将HTTP请求重定向到HTTPS</div>
        </el-form-item>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="deployCertificateVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmDeploy">部署</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 确认对话框 -->
    <el-dialog
      v-model="confirmDialogVisible"
      title="确认操作"
      width="30%"
    >
      <span>{{ confirmMessage }}</span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="confirmDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmAction">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { View, Download, Upload, RefreshRight, Edit, Delete, Search } from '@element-plus/icons-vue'

// 证书列表数据
const certificates = ref([])
const loading = ref(true)
const searchQuery = ref('')
const currentPage = ref(1)
const pageSize = ref(10)

// 网站列表（用于部署证书）
const websites = ref([])

// 证书详情对话框
const certificateDetailsVisible = ref(false)
const dialogTitle = ref('添加SSL证书')
const certificateForm = ref({
  id: null,
  name: '',
  domain: '',
  type: 'lets_encrypt',
  email: '',
  autoRenew: true,
  certFile: null,
  keyFile: null
})

// 证书查看对话框
const viewCertificateVisible = ref(false)
const selectedCertificate = ref({})
const activeCertTab = ref('info')

// 部署证书对话框
const deployCertificateVisible = ref(false)
const deployForm = ref({
  website: '',
  deployMethod: 'nginx',
  forceHttps: true
})

// 确认对话框
const confirmDialogVisible = ref(false)
const confirmMessage = ref('')
const pendingAction = ref(null)

// 表单验证规则
const formRules = {
  name: [{ required: true, message: '请输入证书名称', trigger: 'blur' }],
  domain: [{ required: true, message: '请输入域名', trigger: 'blur' }],
  email: [{ required: true, message: '请输入邮箱地址', trigger: 'blur' }]
}

// 过滤后的证书列表
const filteredCertificates = computed(() => {
  if (!searchQuery.value) {
    return certificates.value
  }
  
  const query = searchQuery.value.toLowerCase()
  return certificates.value.filter(cert => {
    return cert.name.toLowerCase().includes(query) ||
           cert.domain.toLowerCase().includes(query) ||
           cert.issuer.toLowerCase().includes(query)
  })
})

// 获取状态类型
const getStatusType = (status) => {
  const statusMap = {
    '有效': 'success',
    '已过期': 'danger',
    '即将过期': 'warning',
    '吊销': 'info'
  }
  return statusMap[status] || ''
}

// 获取到期时间标签类型
const getExpiryTagType = (expiryDate) => {
  const expiry = new Date(expiryDate)
  const now = new Date()
  const diffDays = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24))
  
  if (diffDays < 0) {
    return 'danger' // 已过期
  } else if (diffDays < 30) {
    return 'warning' // 即将过期
  } else {
    return 'success' // 有效
  }
}

// 刷新证书列表
const refreshCertificates = async () => {
  loading.value = true
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // 生成模拟数据
    const statuses = ['有效', '即将过期', '已过期', '吊销']
    const issuers = ['Let\'s Encrypt', 'DigiCert', 'Comodo', 'GeoTrust', 'GlobalSign']
    const algorithms = ['RSA', 'ECDSA']
    
    const mockCertificates = Array.from({ length: 15 }, (_, i) => {
      const name = `cert-${i + 1}`
      const domain = i % 3 === 0 ? `*.example${i}.com` : `example${i}.com`
      const issuer = issuers[Math.floor(Math.random() * issuers.length)]
      const status = statuses[Math.floor(Math.random() * statuses.length)]
      const algorithm = algorithms[Math.floor(Math.random() * algorithms.length)]
      
      // 生成随机日期（过去一年内）
      const createdDate = new Date()
      createdDate.setDate(createdDate.getDate() - Math.floor(Math.random() * 365))
      const created = createdDate.toISOString().split('T')[0] + ' ' + createdDate.toTimeString().split(' ')[0]
      
      // 生成到期日期（创建日期后的1-2年）
      const expiryDate = new Date(createdDate)
      expiryDate.setFullYear(expiryDate.getFullYear() + (Math.floor(Math.random() * 2) + 1))
      const expiry = expiryDate.toISOString().split('T')[0] + ' ' + expiryDate.toTimeString().split(' ')[0]
      
      return {
        id: i + 1,
        name,
        domain,
        issuer,
        status,
        created,
        expiry,
        autoRenew: Math.random() > 0.5,
        algorithm,
        keyLength: algorithm === 'RSA' ? '2048' : '256',
        serialNumber: Math.random().toString(16).substring(2, 10).toUpperCase(),
        certInfo: `-----BEGIN CERTIFICATE-----\nMIIFazCCA1OgAwIBAgIUXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=\n-----END CERTIFICATE-----`,
        certChain: `-----BEGIN CERTIFICATE-----\nMIIFazCCA1OgAwIBAgIUXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY=\n-----END CERTIFICATE-----`
      }
    })
    
    certificates.value = mockCertificates
    
    // 模拟网站数据（用于部署证书）
    const mockWebsites = Array.from({ length: 5 }, (_, i) => ({
      id: i + 1,
      name: `Website ${i + 1}`,
      domain: `example${i}.com`
    }))
    
    websites.value = mockWebsites
  } catch (error) {
    console.error('Failed to fetch certificates:', error)
    ElMessage.error('获取证书列表失败')
  } finally {
    loading.value = false
  }
}

// 创建证书
const createCertificate = () => {
  dialogTitle.value = '添加SSL证书'
  certificateForm.value = {
    id: null,
    name: '',
    domain: '',
    type: 'lets_encrypt',
    email: '',
    autoRenew: true,
    certFile: null,
    keyFile: null
  }
  certificateDetailsVisible.value = true
}

// 编辑证书
const editCertificate = (certificate) => {
  dialogTitle.value = '编辑SSL证书'
  certificateForm.value = { 
    ...certificate,
    type: certificate.issuer === 'Let\'s Encrypt' ? 'lets_encrypt' : 'custom'
  }
  certificateDetailsVisible.value = true
}

// 查看证书
const viewCertificate = (certificate) => {
  selectedCertificate.value = { ...certificate }
  viewCertificateVisible.value = true
}

// 下载证书
const downloadCertificate = (certificate) => {
  ElMessage.success(`开始下载证书: ${certificate.name}`)
  // 实际应用中应该触发下载
}

// 部署证书
const deployCertificate = (certificate) => {
  selectedCertificate.value = { ...certificate }
  deployForm.value = {
    website: '',
    deployMethod: 'nginx',
    forceHttps: true
  }
  deployCertificateVisible.value = true
}

// 确认部署
const confirmDeploy = async () => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    const website = websites.value.find(w => w.id === deployForm.value.website)
    if (website) {
      ElMessage.success(`证书 ${selectedCertificate.value.name} 已成功部署到 ${website.name}`)
      deployCertificateVisible.value = false
    } else {
      ElMessage.error('请选择要部署的网站')
    }
  } catch (error) {
    console.error('Failed to deploy certificate:', error)
    ElMessage.error('部署证书失败')
  }
}

// 续期证书
const renewCertificate = (certificate) => {
  confirmMessage.value = `确定要续期证书 ${certificate.name} 吗？`
  pendingAction.value = async () => {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500))
      
      // 更新到期时间（当前日期后的1年）
      const expiryDate = new Date()
      expiryDate.setFullYear(expiryDate.getFullYear() + 1)
      const expiry = expiryDate.toISOString().split('T')[0] + ' ' + expiryDate.toTimeString().split(' ')[0]
      
      const index = certificates.value.findIndex(c => c.id === certificate.id)
      if (index !== -1) {
        certificates.value[index].expiry = expiry
        certificates.value[index].status = '有效'
      }
      
      ElMessage.success(`证书 ${certificate.name} 已成功续期`)
    } catch (error) {
      console.error('Failed to renew certificate:', error)
      ElMessage.error('续期证书失败')
    } finally {
      confirmDialogVisible.value = false
    }
  }
  confirmDialogVisible.value = true
}

// 删除证书
const deleteCertificate = (certificate) => {
  confirmMessage.value = `确定要删除证书 ${certificate.name} 吗？此操作不可恢复！`
  pendingAction.value = () => {
    // 模拟API请求
    certificates.value = certificates.value.filter(c => c.id !== certificate.id)
    ElMessage.success(`已删除证书 ${certificate.name}`)
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 处理证书文件上传
const handleCertFileChange = (file) => {
  certificateForm.value.certFile = file
}

// 处理私钥文件上传
const handleKeyFileChange = (file) => {
  certificateForm.value.keyFile = file
}

// 保存证书
const saveCertificate = async () => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    if (certificateForm.value.id) {
      // 更新现有证书
      const index = certificates.value.findIndex(c => c.id === certificateForm.value.id)
      if (index !== -1) {
        certificates.value[index] = { 
          ...certificates.value[index],
          name: certificateForm.value.name,
          domain: certificateForm.value.domain,
          autoRenew: certificateForm.value.autoRenew
        }
        ElMessage.success('证书更新成功')
      }
    } else {
      // 创建新证书
      const newId = Math.max(...certificates.value.map(c => c.id), 0) + 1
      const now = new Date()
      const created = now.toISOString().split('T')[0] + ' ' + now.toTimeString().split(' ')[0]
      
      // 生成到期日期（当前日期后的1年）
      const expiryDate = new Date()
      expiryDate.setFullYear(expiryDate.getFullYear() + 1)
      const expiry = expiryDate.toISOString().split('T')[0] + ' ' + expiryDate.toTimeString().split(' ')[0]
      
      certificates.value.push({
        id: newId,
        name: certificateForm.value.name,
        domain: certificateForm.value.domain,
        issuer: certificateForm.value.type === 'lets_encrypt' ? 'Let\'s Encrypt' : '自定义',
        status: '有效',
        created,
        expiry,
        autoRenew: certificateForm.value.autoRenew,
        algorithm: 'RSA',
        keyLength: '2048',
        serialNumber: Math.random().toString(16).substring(2, 10).toUpperCase(),
        certInfo: `-----BEGIN CERTIFICATE-----\nMIIFazCCA1OgAwIBAgIUXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=\n-----END CERTIFICATE-----`,
        certChain: `-----BEGIN CERTIFICATE-----\nMIIFazCCA1OgAwIBAgIUXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY=\n-----END CERTIFICATE-----`
      })
      ElMessage.success('证书创建成功')
    }
    
    certificateDetailsVisible.value = false
  } catch (error) {
    console.error('Failed to save certificate:', error)
    ElMessage.error('保存证书失败')
  }
}

// 确认操作
const confirmAction = () => {
  if (pendingAction.value) {
    pendingAction.value()
  }
}

// 分页处理
const handleSizeChange = (size) => {
  pageSize.value = size
}

const handleCurrentChange = (page) => {
  currentPage.value = page
}

onMounted(() => {
  // 初始加载
  refreshCertificates()
})
</script>

<style scoped>
.ssl-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.search-input {
  width: 250px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.form-item-description {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
</style>