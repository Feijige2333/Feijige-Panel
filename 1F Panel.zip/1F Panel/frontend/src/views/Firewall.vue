<template>
  <div class="firewall-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <h3>防火墙设置</h3>
          <div class="header-actions">
            <el-button type="primary" @click="refreshRules">刷新</el-button>
            <el-button type="success" @click="createRule">添加规则</el-button>
          </div>
        </div>
      </template>

      <el-tabs v-model="activeTab">
        <el-tab-pane label="防火墙规则" name="rules">
          <el-table
            :data="filteredRules"
            style="width: 100%"
            v-loading="loading"
            border
            stripe
          >
            <el-table-column prop="id" label="ID" width="80" sortable />
            <el-table-column prop="name" label="规则名称" min-width="150" sortable />
            <el-table-column prop="protocol" label="协议" width="100" sortable>
              <template #default="{ row }">
                <el-tag :type="getProtocolType(row.protocol)">{{ row.protocol }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="port" label="端口" width="100" sortable />
            <el-table-column prop="source" label="来源IP" min-width="150" sortable />
            <el-table-column prop="action" label="动作" width="100" sortable>
              <template #default="{ row }">
                <el-tag :type="getActionType(row.action)">{{ row.action }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="status" label="状态" width="100" sortable>
              <template #default="{ row }">
                <el-switch
                  v-model="row.status"
                  :active-value="'启用'"
                  :inactive-value="'禁用'"
                  @change="toggleRuleStatus(row)"
                />
              </template>
            </el-table-column>
            <el-table-column label="操作" width="200" fixed="right">
              <template #default="{ row }">
                <el-button-group>
                  <el-tooltip content="编辑" placement="top">
                    <el-button size="small" type="primary" @click="editRule(row)">
                      <el-icon><Edit /></el-icon>
                    </el-button>
                  </el-tooltip>
                  <el-tooltip content="删除" placement="top">
                    <el-button size="small" type="danger" @click="deleteRule(row)">
                      <el-icon><Delete /></el-icon>
                    </el-button>
                  </el-tooltip>
                </el-button-group>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        
        <el-tab-pane label="端口管理" name="ports">
          <div class="port-management">
            <el-row :gutter="20">
              <el-col :span="12">
                <el-card class="port-card">
                  <template #header>
                    <div class="port-card-header">
                      <h4>开放端口</h4>
                      <el-button type="primary" size="small" @click="openPortDialog">添加端口</el-button>
                    </div>
                  </template>
                  <el-table :data="openPorts" style="width: 100%">
                    <el-table-column prop="port" label="端口" width="100" />
                    <el-table-column prop="service" label="服务" min-width="150" />
                    <el-table-column prop="protocol" label="协议" width="100" />
                    <el-table-column label="操作" width="100">
                      <template #default="{ row }">
                        <el-button size="small" type="danger" @click="closePort(row)">关闭</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </el-card>
              </el-col>
              
              <el-col :span="12">
                <el-card class="port-card">
                  <template #header>
                    <div class="port-card-header">
                      <h4>常用端口</h4>
                    </div>
                  </template>
                  <el-table :data="commonPorts" style="width: 100%">
                    <el-table-column prop="port" label="端口" width="100" />
                    <el-table-column prop="service" label="服务" min-width="150" />
                    <el-table-column prop="description" label="描述" min-width="200" show-overflow-tooltip />
                    <el-table-column label="操作" width="100">
                      <template #default="{ row }">
                        <el-button 
                          size="small" 
                          type="success" 
                          @click="addCommonPort(row)"
                          :disabled="isPortOpen(row.port)"
                        >
                          {{ isPortOpen(row.port) ? '已开放' : '开放' }}
                        </el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>
        
        <el-tab-pane label="安全策略" name="policies">
          <el-form :model="securityPolicy" label-width="180px">
            <el-form-item label="默认防火墙策略">
              <el-radio-group v-model="securityPolicy.defaultPolicy">
                <el-radio label="accept">允许所有连接（不推荐）</el-radio>
                <el-radio label="drop">拒绝所有连接</el-radio>
              </el-radio-group>
            </el-form-item>
            
            <el-form-item label="SSH暴力破解防护">
              <el-switch v-model="securityPolicy.sshBruteforceProtection" />
              <div class="form-item-description">启用后，系统将自动封禁多次SSH登录失败的IP地址</div>
            </el-form-item>
            
            <el-form-item label="SSH登录失败次数阈值" v-if="securityPolicy.sshBruteforceProtection">
              <el-input-number v-model="securityPolicy.sshFailThreshold" :min="3" :max="20" />
            </el-form-item>
            
            <el-form-item label="封禁时长(分钟)" v-if="securityPolicy.sshBruteforceProtection">
              <el-input-number v-model="securityPolicy.banDuration" :min="5" :max="1440" />
            </el-form-item>
            
            <el-form-item label="DDoS防护">
              <el-switch v-model="securityPolicy.ddosProtection" />
              <div class="form-item-description">启用后，系统将自动检测并阻止DDoS攻击</div>
            </el-form-item>
            
            <el-form-item label="IP白名单">
              <el-select
                v-model="securityPolicy.whitelistIps"
                multiple
                filterable
                allow-create
                default-first-option
                placeholder="请输入IP地址，回车确认"
                style="width: 100%"
              />
              <div class="form-item-description">白名单中的IP地址将不受任何防火墙规则限制</div>
            </el-form-item>
            
            <el-form-item>
              <el-button type="primary" @click="saveSecurityPolicy">保存设置</el-button>
              <el-button @click="resetSecurityPolicy">重置</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>
    </el-card>

    <!-- 规则详情对话框 -->
    <el-dialog
      v-model="ruleDialogVisible"
      :title="dialogTitle"
      width="50%"
      destroy-on-close
    >
      <el-form
        ref="ruleForm"
        :model="ruleForm"
        label-width="120px"
        :rules="formRules"
      >
        <el-form-item label="规则名称" prop="name">
          <el-input v-model="ruleForm.name" placeholder="请输入规则名称" />
        </el-form-item>
        <el-form-item label="协议类型" prop="protocol">
          <el-select v-model="ruleForm.protocol" placeholder="选择协议" style="width: 100%">
            <el-option label="TCP" value="TCP" />
            <el-option label="UDP" value="UDP" />
            <el-option label="ICMP" value="ICMP" />
            <el-option label="全部" value="ALL" />
          </el-select>
        </el-form-item>
        <el-form-item label="端口" prop="port" v-if="ruleForm.protocol !== 'ICMP'">
          <el-input v-model="ruleForm.port" placeholder="单个端口或端口范围，如：80或8000-9000" />
        </el-form-item>
        <el-form-item label="来源IP" prop="source">
          <el-input v-model="ruleForm.source" placeholder="IP地址、CIDR格式或'any'" />
        </el-form-item>
        <el-form-item label="动作" prop="action">
          <el-select v-model="ruleForm.action" placeholder="选择动作" style="width: 100%">
            <el-option label="允许" value="ACCEPT" />
            <el-option label="拒绝" value="DROP" />
            <el-option label="记录" value="LOG" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-switch
            v-model="ruleForm.status"
            :active-value="'启用'"
            :inactive-value="'禁用'"
          />
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input
            v-model="ruleForm.description"
            type="textarea"
            :rows="2"
            placeholder="规则描述（可选）"
          />
        </el-form-item>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="ruleDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="saveRule">保存</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 端口对话框 -->
    <el-dialog
      v-model="portDialogVisible"
      title="添加端口"
      width="40%"
      destroy-on-close
    >
      <el-form
        ref="portForm"
        :model="portForm"
        label-width="120px"
        :rules="portFormRules"
      >
        <el-form-item label="端口" prop="port">
          <el-input v-model="portForm.port" placeholder="请输入端口号" />
        </el-form-item>
        <el-form-item label="服务名称" prop="service">
          <el-input v-model="portForm.service" placeholder="请输入服务名称" />
        </el-form-item>
        <el-form-item label="协议" prop="protocol">
          <el-select v-model="portForm.protocol" placeholder="选择协议" style="width: 100%">
            <el-option label="TCP" value="TCP" />
            <el-option label="UDP" value="UDP" />
            <el-option label="TCP/UDP" value="TCP/UDP" />
          </el-select>
        </el-form-item>
      </el-form>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="portDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="savePort">保存</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 确认对话框 -->
    <el-dialog
      v-model="confirmDialogVisible"
      title="确认操作"
      width="30%"
    >
      <span>{{ confirmMessage }}</span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="confirmDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmAction">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Edit, Delete } from '@element-plus/icons-vue'

// 标签页
const activeTab = ref('rules')

// 防火墙规则数据
const rules = ref([])
const loading = ref(true)
const filteredRules = computed(() => rules.value)

// 端口数据
const openPorts = ref([])
const commonPorts = ref([
  { port: '22', service: 'SSH', description: '安全Shell远程登录' },
  { port: '80', service: 'HTTP', description: '网站服务' },
  { port: '443', service: 'HTTPS', description: '安全网站服务' },
  { port: '3306', service: 'MySQL', description: 'MySQL数据库服务' },
  { port: '8080', service: 'Web代理', description: '常用的Web代理端口' },
  { port: '21', service: 'FTP', description: '文件传输协议' },
  { port: '25', service: 'SMTP', description: '邮件发送服务' },
  { port: '110', service: 'POP3', description: '邮件接收服务' },
  { port: '143', service: 'IMAP', description: '邮件接收服务' },
  { port: '53', service: 'DNS', description: '域名解析服务' }
])

// 安全策略
const securityPolicy = ref({
  defaultPolicy: 'drop',
  sshBruteforceProtection: true,
  sshFailThreshold: 5,
  banDuration: 30,
  ddosProtection: true,
  whitelistIps: ['127.0.0.1']
})

// 规则对话框
const ruleDialogVisible = ref(false)
const dialogTitle = ref('添加规则')
const ruleForm = ref({
  id: null,
  name: '',
  protocol: 'TCP',
  port: '',
  source: '',
  action: 'ACCEPT',
  status: '启用',
  description: ''
})

// 端口对话框
const portDialogVisible = ref(false)
const portForm = ref({
  port: '',
  service: '',
  protocol: 'TCP'
})

// 确认对话框
const confirmDialogVisible = ref(false)
const confirmMessage = ref('')
const pendingAction = ref(null)

// 表单验证规则
const formRules = {
  name: [{ required: true, message: '请输入规则名称', trigger: 'blur' }],
  protocol: [{ required: true, message: '请选择协议类型', trigger: 'change' }],
  port: [{ required: true, message: '请输入端口', trigger: 'blur' }],
  source: [{ required: true, message: '请输入来源IP', trigger: 'blur' }],
  action: [{ required: true, message: '请选择动作', trigger: 'change' }]
}

// 端口表单验证规则
const portFormRules = {
  port: [{ required: true, message: '请输入端口号', trigger: 'blur' }],
  service: [{ required: true, message: '请输入服务名称', trigger: 'blur' }],
  protocol: [{ required: true, message: '请选择协议', trigger: 'change' }]
}

// 获取协议类型颜色
const getProtocolType = (protocol) => {
  const protocolMap = {
    'TCP': '',
    'UDP': 'success',
    'ICMP': 'info',
    'ALL': 'warning'
  }
  return protocolMap[protocol] || ''
}

// 获取动作类型颜色
const getActionType = (action) => {
  const actionMap = {
    'ACCEPT': 'success',
    'DROP': 'danger',
    'LOG': 'info'
  }
  return actionMap[action] || ''
}

// 刷新规则列表
const refreshRules = async () => {
  loading.value = true
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // 生成模拟数据
    const protocols = ['TCP', 'UDP', 'ICMP', 'ALL']
    const actions = ['ACCEPT', 'DROP', 'LOG']
    const statuses = ['启用', '禁用']
    
    const mockRules = Array.from({ length: 10 }, (_, i) => {
      const protocol = protocols[Math.floor(Math.random() * protocols.length)]
      const action = actions[Math.floor(Math.random() * actions.length)]
      const status = statuses[Math.floor(Math.random() * statuses.length)]
      
      return {
        id: i + 1,
        name: `Rule-${i + 1}`,
        protocol,
        port: protocol === 'ICMP' ? '' : Math.floor(Math.random() * 65535).toString(),
        source: `192.168.1.${Math.floor(Math.random() * 255)}`,
        action,
        status,
        description: `防火墙规则 ${i + 1} 描述`
      }
    })
    
    rules.value = mockRules
    
    // 模拟开放端口数据
    const mockOpenPorts = [
      { port: '22', service: 'SSH', protocol: 'TCP' },
      { port: '80', service: 'HTTP', protocol: 'TCP' },
      { port: '443', service: 'HTTPS', protocol: 'TCP' },
      { port: '3306', service: 'MySQL', protocol: 'TCP' },
      { port: '53', service: 'DNS', protocol: 'UDP' }
    ]
    
    openPorts.value = mockOpenPorts
  } catch (error) {
    console.error('Failed to fetch firewall rules:', error)
    ElMessage.error('获取防火墙规则失败')
  } finally {
    loading.value = false
  }
}

// 创建规则
const createRule = () => {
  dialogTitle.value = '添加规则'
  ruleForm.value = {
    id: null,
    name: '',
    protocol: 'TCP',
    port: '',
    source: '',
    action: 'ACCEPT',
    status: '启用',
    description: ''
  }
  ruleDialogVisible.value = true
}

// 编辑规则
const editRule = (rule) => {
  dialogTitle.value = '编辑规则'
  ruleForm.value = { ...rule }
  ruleDialogVisible.value = true
}

// 保存规则
const saveRule = async () => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    if (ruleForm.value.id) {
      // 更新现有规则
      const index = rules.value.findIndex(r => r.id === ruleForm.value.id)
      if (index !== -1) {
        rules.value[index] = { ...ruleForm.value }
        ElMessage.success('规则更新成功')
      }
    } else {
      // 创建新规则
      const newId = Math.max(...rules.value.map(r => r.id), 0) + 1
      rules.value.push({
        ...ruleForm.value,
        id: newId
      })
      ElMessage.success('规则创建成功')
    }
    
    ruleDialogVisible.value = false
  } catch (error) {
    console.error('Failed to save rule:', error)
    ElMessage.error('保存规则失败')
  }
}

// 删除规则
const deleteRule = (rule) => {
  confirmMessage.value = `确定要删除规则 ${rule.name} 吗？`
  pendingAction.value = () => {
    // 模拟API请求
    rules.value = rules.value.filter(r => r.id !== rule.id)
    ElMessage.success(`已删除规则 ${rule.name}`)
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 切换规则状态
const toggleRuleStatus = async (rule) => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    ElMessage.success(`规则 ${rule.name} 已${rule.status === '启用' ? '启用' : '禁用'}`)
  } catch (error) {
    console.error('Failed to toggle rule status:', error)
    ElMessage.error('更改规则状态失败')
    // 恢复原状态
    rule.status = rule.status === '启用' ? '禁用' : '启用'
  }
}

// 打开端口对话框
const openPortDialog = () => {
  portForm.value = {
    port: '',
    service: '',
    protocol: 'TCP'
  }
  portDialogVisible.value = true
}

// 保存端口
const savePort = async () => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // 检查端口是否已存在
    if (openPorts.value.some(p => p.port === portForm.value.port)) {
      ElMessage.warning('该端口已开放')
      return
    }
    
    openPorts.value.push({ ...portForm.value })
    ElMessage.success(`端口 ${portForm.value.port} 已开放`)
    portDialogVisible.value = false
  } catch (error) {
    console.error('Failed to save port:', error)
    ElMessage.error('开放端口失败')
  }
}

// 关闭端口
const closePort = (port) => {
  confirmMessage.value = `确定要关闭端口 ${port.port} (${port.service}) 吗？`
  pendingAction.value = () => {
    // 模拟API请求
    openPorts.value = openPorts.value.filter(p => p.port !== port.port)
    ElMessage.success(`已关闭端口 ${port.port}`)
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 添加常用端口
const addCommonPort = async (port) => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // 检查端口是否已存在
    if (openPorts.value.some(p => p.port === port.port)) {
      ElMessage.warning('该端口已开放')
      return
    }
    
    openPorts.value.push({
      port: port.port,
      service: port.service,
      protocol: port.protocol || 'TCP'
    })
    ElMessage.success(`端口 ${port.port} 已开放`)
  } catch (error) {
    console.error('Failed to add common port:', error)
    ElMessage.error('开放端口失败')
  }
}

// 检查端口是否已开放
const isPortOpen = (port) => {
  return openPorts.value.some(p => p.port === port)
}

// 保存安全策略
const saveSecurityPolicy = async () => {
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    ElMessage.success('安全策略保存成功')
  } catch (error) {
    console.error('Failed to save security policy:', error)
    ElMessage.error('保存安全策略失败')
  }
}

// 重置安全策略
const resetSecurityPolicy = () => {
  securityPolicy.value = {
    defaultPolicy: 'drop',
    sshBruteforceProtection: true,
    sshFailThreshold: 5,
    banDuration: 30,
    ddosProtection: true,
    whitelistIps: ['127.0.0.1']
  }
}

// 确认操作
const confirmAction = () => {
  if (pendingAction.value) {
    pendingAction.value()
  }
}

onMounted(() => {
  // 初始加载
  refreshRules()
})
</script>

<style scoped>
.firewall-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.port-management {
  margin-top: 20px;
}

.port-card {
  margin-bottom: 20px;
}

.port-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.form-item-description {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
</style>