<template>
  <div class="processes-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <h3>进程管理</h3>
          <div class="header-actions">
            <el-input
              v-model="searchQuery"
              placeholder="搜索进程"
              prefix-icon="Search"
              clearable
              class="search-input"
            />
            <el-button type="primary" @click="refreshProcesses">刷新</el-button>
          </div>
        </div>
      </template>

      <el-table
        :data="filteredProcesses"
        style="width: 100%"
        v-loading="loading"
        border
        stripe
        :default-sort="{ prop: 'cpu', order: 'descending' }"
      >
        <el-table-column prop="pid" label="PID" width="100" sortable />
        <el-table-column prop="user" label="用户" width="120" sortable />
        <el-table-column prop="name" label="进程名称" min-width="200" sortable>
          <template #default="{ row }">
            <el-tooltip :content="row.command" placement="top" :show-after="500">
              <span>{{ row.name }}</span>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column prop="cpu" label="CPU (%)" width="120" sortable>
          <template #default="{ row }">
            <div class="resource-usage">
              <span>{{ row.cpu }}%</span>
              <el-progress :percentage="row.cpu" :color="getCpuColor(row.cpu)" :show-text="false" />
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="memory" label="内存 (%)" width="120" sortable>
          <template #default="{ row }">
            <div class="resource-usage">
              <span>{{ row.memory }}%</span>
              <el-progress :percentage="row.memory" :color="getMemoryColor(row.memory)" :show-text="false" />
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100" sortable>
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="time" label="运行时间" width="150" sortable />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-button size="small" type="danger" @click="killProcess(row)">
                <el-icon><Close /></el-icon> 终止
              </el-button>
              <el-button size="small" type="warning" @click="restartProcess(row)">
                <el-icon><RefreshRight /></el-icon> 重启
              </el-button>
              <el-button size="small" type="info" @click="viewProcessDetails(row)">
                <el-icon><InfoFilled /></el-icon> 详情
              </el-button>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="filteredProcesses.length"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 进程详情对话框 -->
    <el-dialog
      v-model="processDetailsVisible"
      title="进程详情"
      width="60%"
      destroy-on-close
    >
      <template v-if="selectedProcess">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="PID">{{ selectedProcess.pid }}</el-descriptions-item>
          <el-descriptions-item label="用户">{{ selectedProcess.user }}</el-descriptions-item>
          <el-descriptions-item label="进程名称">{{ selectedProcess.name }}</el-descriptions-item>
          <el-descriptions-item label="状态">{{ selectedProcess.status }}</el-descriptions-item>
          <el-descriptions-item label="CPU 使用率">{{ selectedProcess.cpu }}%</el-descriptions-item>
          <el-descriptions-item label="内存使用率">{{ selectedProcess.memory }}%</el-descriptions-item>
          <el-descriptions-item label="运行时间">{{ selectedProcess.time }}</el-descriptions-item>
          <el-descriptions-item label="优先级">{{ selectedProcess.priority }}</el-descriptions-item>
          <el-descriptions-item label="完整命令" :span="2">{{ selectedProcess.command }}</el-descriptions-item>
        </el-descriptions>

        <template #footer>
          <span class="dialog-footer">
            <el-button @click="processDetailsVisible = false">关闭</el-button>
            <el-button type="danger" @click="killProcessFromDialog">终止进程</el-button>
          </span>
        </template>
      </template>
    </el-dialog>

    <!-- 确认对话框 -->
    <el-dialog
      v-model="confirmDialogVisible"
      title="确认操作"
      width="30%"
    >
      <span>{{ confirmMessage }}</span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="confirmDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmAction">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Close, RefreshRight, InfoFilled, Search } from '@element-plus/icons-vue'

// 进程列表数据
const processes = ref([])
const loading = ref(true)
const searchQuery = ref('')
const currentPage = ref(1)
const pageSize = ref(20)

// 进程详情对话框
const processDetailsVisible = ref(false)
const selectedProcess = ref(null)

// 确认对话框
const confirmDialogVisible = ref(false)
const confirmMessage = ref('')
const pendingAction = ref(null)

// 过滤后的进程列表
const filteredProcesses = computed(() => {
  if (!searchQuery.value) {
    return processes.value
  }
  
  const query = searchQuery.value.toLowerCase()
  return processes.value.filter(process => {
    return process.name.toLowerCase().includes(query) ||
           process.user.toLowerCase().includes(query) ||
           process.pid.toString().includes(query) ||
           process.command.toLowerCase().includes(query)
  })
})

// 获取CPU颜色
const getCpuColor = (value) => {
  if (value < 50) return '#67C23A'
  if (value < 80) return '#E6A23C'
  return '#F56C6C'
}

// 获取内存颜色
const getMemoryColor = (value) => {
  if (value < 50) return '#67C23A'
  if (value < 80) return '#E6A23C'
  return '#F56C6C'
}

// 获取状态类型
const getStatusType = (status) => {
  const statusMap = {
    '运行中': 'success',
    '睡眠': 'info',
    '僵尸': 'danger',
    '停止': 'warning',
    '等待': 'info'
  }
  return statusMap[status] || ''
}

// 刷新进程列表
const refreshProcesses = async () => {
  loading.value = true
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // 生成模拟数据
    const statuses = ['运行中', '睡眠', '僵尸', '停止', '等待']
    const users = ['root', 'www-data', 'mysql', 'nginx', 'admin', 'system']
    const processNames = [
      'nginx', 'apache2', 'mysql', 'php-fpm', 'node', 'python', 'java',
      'redis-server', 'mongod', 'sshd', 'cron', 'systemd', 'bash', 'docker'
    ]
    
    const mockProcesses = Array.from({ length: 100 }, (_, i) => {
      const name = processNames[Math.floor(Math.random() * processNames.length)]
      const pid = Math.floor(Math.random() * 10000) + 1000
      const cpu = parseFloat((Math.random() * 100).toFixed(1))
      const memory = parseFloat((Math.random() * 100).toFixed(1))
      const user = users[Math.floor(Math.random() * users.length)]
      const status = statuses[Math.floor(Math.random() * statuses.length)]
      const hours = Math.floor(Math.random() * 24)
      const minutes = Math.floor(Math.random() * 60)
      const seconds = Math.floor(Math.random() * 60)
      const time = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      const priority = Math.floor(Math.random() * 20) - 10
      const command = `/usr/bin/${name} --config=/etc/${name}.conf --port=${Math.floor(Math.random() * 1000) + 8000}`
      
      return {
        pid,
        user,
        name,
        cpu,
        memory,
        status,
        time,
        priority,
        command
      }
    })
    
    processes.value = mockProcesses
  } catch (error) {
    console.error('Failed to fetch processes:', error)
    ElMessage.error('获取进程列表失败')
  } finally {
    loading.value = false
  }
}

// 查看进程详情
const viewProcessDetails = (process) => {
  selectedProcess.value = process
  processDetailsVisible.value = true
}

// 终止进程
const killProcess = (process) => {
  confirmMessage.value = `确定要终止进程 ${process.name} (PID: ${process.pid}) 吗？`
  pendingAction.value = () => {
    // 模拟API请求
    ElMessage.success(`已终止进程 ${process.name} (PID: ${process.pid})`)
    // 从列表中移除
    processes.value = processes.value.filter(p => p.pid !== process.pid)
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 从对话框中终止进程
const killProcessFromDialog = () => {
  if (selectedProcess.value) {
    killProcess(selectedProcess.value)
    processDetailsVisible.value = false
  }
}

// 重启进程
const restartProcess = (process) => {
  confirmMessage.value = `确定要重启进程 ${process.name} (PID: ${process.pid}) 吗？`
  pendingAction.value = () => {
    // 模拟API请求
    ElMessage.success(`已重启进程 ${process.name} (PID: ${process.pid})`)
    // 更新状态
    const index = processes.value.findIndex(p => p.pid === process.pid)
    if (index !== -1) {
      processes.value[index].status = '运行中'
      processes.value[index].time = '00:00:01'
    }
    confirmDialogVisible.value = false
  }
  confirmDialogVisible.value = true
}

// 确认操作
const confirmAction = () => {
  if (pendingAction.value) {
    pendingAction.value()
  }
}

// 分页处理
const handleSizeChange = (size) => {
  pageSize.value = size
}

const handleCurrentChange = (page) => {
  currentPage.value = page
}

// 定时刷新
let refreshTimer = null

onMounted(() => {
  // 初始加载
  refreshProcesses()
  
  // 设置定时刷新 (每30秒)
  refreshTimer = setInterval(() => {
    refreshProcesses()
  }, 30000)
})

onUnmounted(() => {
  // 清除定时器
  if (refreshTimer) {
    clearInterval(refreshTimer)
  }
})
</script>

<style scoped>
.processes-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.search-input {
  width: 250px;
}

.resource-usage {
  display: flex;
  flex-direction: column;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
</style>