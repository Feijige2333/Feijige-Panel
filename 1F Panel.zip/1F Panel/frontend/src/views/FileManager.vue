<template>
  <div class="file-manager-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <h3>文件管理</h3>
          <div class="header-actions">
            <el-input
              v-model="searchQuery"
              placeholder="搜索文件"
              prefix-icon="Search"
              clearable
              class="search-input"
            />
            <el-button type="primary" @click="refreshFiles">刷新</el-button>
            <el-upload
              class="upload-button"
              :action="uploadUrl"
              :auto-upload="false"
              :on-change="handleFileChange"
              :show-file-list="false"
              :multiple="true"
            >
              <el-button type="success">上传文件</el-button>
            </el-upload>
            <el-button type="primary" @click="createFolder">新建文件夹</el-button>
          </div>
        </div>
      </template>

      <!-- 路径导航 -->
      <div class="path-navigation">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item :to="{ path: '/' }">
            <el-icon><HomeFilled /></el-icon> 根目录
          </el-breadcrumb-item>
          <el-breadcrumb-item 
            v-for="(segment, index) in pathSegments" 
            :key="index"
            :to="getPathTo(index)"
          >
            {{ segment }}
          </el-breadcrumb-item>
        </el-breadcrumb>
      </div>

      <!-- 文件列表 -->
      <el-table
        :data="filteredFiles"
        style="width: 100%"
        v-loading="loading"
        @row-dblclick="handleRowDblClick"
      >
        <el-table-column width="60">
          <template #default="{ row }">
            <el-icon v-if="row.type === 'folder'" style="color: #e6a23c;">
              <Folder />
            </el-icon>
            <el-icon v-else-if="isImageFile(row.name)" style="color: #409eff;">
              <Picture />
            </el-icon>
            <el-icon v-else-if="isTextFile(row.name)" style="color: #67c23a;">
              <Document />
            </el-icon>
            <el-icon v-else-if="isArchiveFile(row.name)" style="color: #909399;">
              <Files />
            </el-icon>
            <el-icon v-else style="color: #909399;">
              <Document />
            </el-icon>
          </template>
        </el-table-column>
        <el-table-column prop="name" label="名称" sortable min-width="200">
          <template #default="{ row }">
            <div class="file-name" @click="handleFileClick(row)">
              {{ row.name }}
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="size" label="大小" width="120" sortable>
          <template #default="{ row }">
            {{ row.type === 'folder' ? '--' : formatFileSize(row.size) }}
          </template>
        </el-table-column>
        <el-table-column prop="modified" label="修改时间" width="180" sortable />
        <el-table-column prop="permissions" label="权限" width="100" />
        <el-table-column prop="owner" label="所有者" width="120" />
        <el-table-column label="操作" width="240" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="预览" placement="top" v-if="canPreview(row)">
                <el-button size="small" type="primary" @click="previewFile(row)">
                  <el-icon><View /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="编辑" placement="top" v-if="canEdit(row)">
                <el-button size="small" type="primary" @click="editFile(row)">
                  <el-icon><Edit /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="下载" placement="top" v-if="row.type === 'file'">
                <el-button size="small" type="success" @click="downloadFile(row)">
                  <el-icon><Download /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="重命名" placement="top">
                <el-button size="small" type="info" @click="renameFile(row)">
                  <el-icon><EditPen /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="删除" placement="top">
                <el-button size="small" type="danger" @click="deleteFile(row)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="filteredFiles.length"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 文件预览对话框 -->
    <el-dialog
      v-model="previewVisible"
      :title="selectedFile.name"
      width="70%"
      destroy-on-close
    >
      <div class="preview-container">
        <!-- 图片预览 -->
        <div v-if="isImageFile(selectedFile.name)" class="image-preview">
          <img :src="selectedFile.url" alt="Image Preview" />
        </div>
        
        <!-- 文本预览 -->
        <div v-else-if="isTextFile(selectedFile.name)" class="text-preview">
          <el-input
            v-model="fileContent"
            type="textarea"
            :rows="20"
            readonly
          />
        </div>
        
        <!-- 其他文件类型 -->
        <div v-else class="unsupported-preview">
          <el-empty description="无法预览此类型的文件" />
          <el-button type="primary" @click="downloadFile(selectedFile)">下载文件</el-button>
        </div>
      </div>
    </el-dialog>

    <!-- 文件编辑对话框 -->
    <el-dialog
      v-model="editVisible"
      :title="`编辑: ${selectedFile.name}`"
      width="80%"
      destroy-on-close
    >
      <el-input
        v-model="fileContent"
        type="textarea"
        :rows="25"
        :autosize="{ minRows: 25, maxRows: 50 }"
      />
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="editVisible = false">取消</el-button>
          <el-button type="primary" @click="saveFile">保存</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 新建文件夹对话框 -->
    <el-dialog
      v-model="createFolderVisible"
      title="新建文件夹"
      width="30%"
    >
      <el-form :model="folderForm" label-width="80px">
        <el-form-item label="文件夹名">
          <el-input v-model="folderForm.name" placeholder="请输入文件夹名称" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="createFolderVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmCreateFolder">创建</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 重命名对话框 -->
    <el-dialog
      v-model="renameVisible"
      title="重命名"
      width="30%"
    >
      <el-form :model="renameForm" label-width="80px">
        <el-form-item label="新名称">
          <el-input v-model="renameForm.newName" placeholder="请输入新名称" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="renameVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmRename">确认</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 确认对话框 -->
    <el-dialog
      v-model="confirmDialogVisible"
      title="确认操作"
      width="30%"
    >
      <span>{{ confirmMessage }}</span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="confirmDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="confirmAction">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { 
  Folder, Document, Picture, Files, View, Edit, Download, 
  Delete, EditPen, HomeFilled 
} from '@element-plus/icons-vue'

// 文件列表数据
const files = ref([])
const loading = ref(true)
const searchQuery = ref('')
const currentPage = ref(1)
const pageSize = ref(10)
const currentPath = ref('/')
const uploadUrl = ref('/api/files/upload')

// 文件操作相关
const selectedFile = ref({})
const fileContent = ref('')
const previewVisible = ref(false)
const editVisible = ref(false)
const createFolderVisible = ref(false)
const renameVisible = ref(false)
const folderForm = ref({ name: '' })
const renameForm = ref({ newName: '' })

// 确认对话框
const confirmDialogVisible = ref(false)
const confirmMessage = ref('')
const pendingAction = ref(null)

// 路径导航
const pathSegments = computed(() => {
  if (currentPath.value === '/') return []
  return currentPath.value.split('/').filter(segment => segment)
})

// 获取导航路径
const getPathTo = (index) => {
  const segments = pathSegments.value.slice(0, index + 1)
  return '/' + segments.join('/')
}

// 过滤后的文件列表
const filteredFiles = computed(() => {
  if (!searchQuery.value) {
    return files.value
  }
  
  const query = searchQuery.value.toLowerCase()
  return files.value.filter(file => {
    return file.name.toLowerCase().includes(query)
  })
})

// 刷新文件列表
const refreshFiles = async () => {
  loading.value = true
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // 生成模拟数据
    const fileTypes = ['txt', 'jpg', 'png', 'pdf', 'html', 'css', 'js', 'php', 'zip', 'tar.gz']
    const owners = ['root', 'www-data', 'user']
    const permissions = ['644', '755', '777', '600']
    
    // 生成文件夹
    const mockFolders = ['images', 'documents', 'backups', 'logs', 'config'].map((name, index) => ({
      id: `folder-${index}`,
      name,
      type: 'folder',
      size: 0,
      modified: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toLocaleString(),
      permissions: permissions[Math.floor(Math.random() * permissions.length)],
      owner: owners[Math.floor(Math.random() * owners.length)]
    }))
    
    // 生成文件
    const mockFiles = Array.from({ length: 15 }, (_, i) => {
      const fileType = fileTypes[Math.floor(Math.random() * fileTypes.length)]
      const name = `file-${i + 1}.${fileType}`
      return {
        id: `file-${i}`,
        name,
        type: 'file',
        size: Math.floor(Math.random() * 10000000), // 随机大小
        modified: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toLocaleString(),
        permissions: permissions[Math.floor(Math.random() * permissions.length)],
        owner: owners[Math.floor(Math.random() * owners.length)],
        url: fileType.match(/jpg|png/) ? `https://picsum.photos/800/600?random=${i}` : null
      }
    })
    
    files.value = [...mockFolders, ...mockFiles]
  } catch (error) {
    console.error('Failed to fetch files:', error)
    ElMessage.error('获取文件列表失败')
  } finally {
    loading.value = false
  }
}

// 格式化文件大小
const formatFileSize = (size) => {
  if (size < 1024) {
    return `${size} B`
  } else if (size < 1024 * 1024) {
    return `${(size / 1024).toFixed(2)} KB`
  } else if (size < 1024 * 1024 * 1024) {
    return `${(size / (1024 * 1024)).toFixed(2)} MB`
  } else {
    return `${(size / (1024 * 1024 * 1024)).toFixed(2)} GB`
  }
}

// 判断文件类型
const isImageFile = (filename) => {
  return /\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(filename)
}

const isTextFile = (filename) => {
  return /\.(txt|html|css|js|php|json|xml|md|log|conf|ini|sh|py)$/i.test(filename)
}

const isArchiveFile = (filename) => {
  return /\.(zip|tar|gz|rar|7z)$/i.test(filename)
}

// 判断是否可以预览
const canPreview = (file) => {
  return file.type === 'file' && (isImageFile(file.name) || isTextFile(file.name))
}

// 判断是否可以编辑
const canEdit = (file) => {
  return file.type === 'file' && isTextFile(file.name)
}

// 处理文件点击
const handleFileClick = (file) => {
  if (file.type === 'folder') {
    // 导航到文件夹
    navigateToFolder(file.name)
  }
}

// 处理行双击
const handleRowDblClick = (row) => {
  if (row.type === 'folder') {
    navigateToFolder(row.name)
  } else {
    if (canPreview(row)) {
      previewFile(row)
    } else {
      downloadFile(row)
    }
  }
}

// 导航到文件夹
const navigateToFolder = (folderName) => {
  if (currentPath.value === '/') {
    currentPath.value = `/${folderName}`
  } else {
    currentPath.value = `${currentPath.value}/${folderName}`
  }
  refreshFiles()
}

// 预览文件
const previewFile = async (file) => {
  selectedFile.value = file
  
  if (isTextFile(file.name)) {
    try {
      // 模拟获取文件内容
      await new Promise(resolve => setTimeout(resolve, 300))
      fileContent.value = `这是 ${file.name} 的模拟内容。\n\n在实际应用中，这里会显示真实的文件内容。\n\n${Array(20).fill('示例文本行').join('\n')}`
    } catch (error) {
      console.error('Failed to fetch file content:', error)
      ElMessage.error('获取文件内容失败')
      return
    }
  }
  
  previewVisible.value = true
}

// 编辑文件
const editFile = async (file) => {
  selectedFile.value = file
  
  try {
    // 模拟获取文件内容
    await new Promise(resolve => setTimeout(resolve, 300))
    fileContent.value = `这是 ${file.name} 的模拟内容，可以进行编辑。\n\n在实际应用中，这里会显示真实的文件内容。\n\n${Array(20).fill('可编辑的文本行').join('\n')}`
    editVisible.value = true
  } catch (error) {
    console.error('Failed to fetch file content for editing:', error)
    ElMessage.error('获取文件内容失败')
  }
}

// 保存文件
const saveFile = async () => {
  try {
    // 模拟保存文件
    await new Promise(resolve => setTimeout(resolve, 500))
    ElMessage.success(`文件 ${selectedFile.value.name} 已保存`)
    editVisible.value = false
  } catch (error) {
    console.error('Failed to save file:', error)
    ElMessage.error('保存文件失败')
  }
}

// 下载文件
const downloadFile = (file) => {
  ElMessage.success(`开始下载文件: ${file.name}`)
  // 实际应用中应该触发下载
}

// 创建文件夹
const createFolder = () => {
  folderForm.value.name = ''
  createFolderVisible.value = true
}

// 确认创建文件夹
const confirmCreateFolder = async () => {
  if (!folderForm.value.name) {
    ElMessage.warning('请输入文件夹名称')
    return
  }
  
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 300))
    
    // 添加新文件夹到列表
    const newFolder = {
      id: `folder-${Date.now()}`,
      name: folderForm.value.name,
      type: 'folder',
      size: 0,
      modified: new Date().toLocaleString(),
      permissions: '755',
      owner: 'user'
    }
    
    files.value.unshift(newFolder)
    ElMessage.success(`文件夹 ${folderForm.value.name} 创建成功`)
    createFolderVisible.value = false
  } catch (error) {
    console.error('Failed to create folder:', error)
    ElMessage.error('创建文件夹失败')
  }
}

// 重命名文件/文件夹
const renameFile = (file) => {
  selectedFile.value = file
  renameForm.value.newName = file.name
  renameVisible.value = true
}

// 确认重命名
const confirmRename = async () => {
  if (!renameForm.value.newName) {
    ElMessage.warning('请输入新名称')
    return
  }
  
  try {
    // 模拟API请求
    await new Promise(resolve => setTimeout(resolve, 300))
    
    // 更新文件名
    const index = files.value.findIndex(f => f.id === selectedFile.value.id)
    if (index !== -1) {
      files.value[index].name = renameForm.value.newName
      ElMessage.success(`重命名成功`)
      renameVisible.value = false
    }
  } catch (error) {
    console.error('Failed to rename:', error)
    ElMessage.error('重命名失败')
  }
}

// 删除文件/文件夹
const deleteFile = (file) => {
  selectedFile.value = file
  confirmMessage.value = `确定要删除${file.type === 'folder' ? '文件夹' : '文件'} ${file.name} 吗？此操作不可恢复！`
  pendingAction.value = async () => {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 300))
      
      // 从列表中移除
      files.value = files.value.filter(f => f.id !== file.id)
      ElMessage.success(`已删除${file.type === 'folder' ? '文件夹' : '文件'} ${file.name}`)
    } catch (error) {
      console.error('Failed to delete:', error)
      ElMessage.error('删除失败')
    } finally {
      confirmDialogVisible.value = false
    }
  }
  confirmDialogVisible.value = true
}

// 确认操作
const confirmAction = () => {
  if (pendingAction.value) {
    pendingAction.value()
  }
}

// 处理文件上传
const handleFileChange = (file) => {
  // 模拟文件上传
  ElMessage.success(`文件 ${file.name} 上传成功`)
  
  // 添加到文件列表
  const fileType = file.name.split('.').pop().toLowerCase()
  const newFile = {
    id: `file-${Date.now()}`,
    name: file.name,
    type: 'file',
    size: file.size,
    modified: new Date().toLocaleString(),
    permissions: '644',
    owner: 'user',
    url: fileType.match(/jpg|png|jpeg|gif/) ? URL.createObjectURL(file.raw) : null
  }
  
  files.value.unshift(newFile)
}

// 分页处理
const handleSizeChange = (val) => {
  pageSize.value = val
  currentPage.value = 1
}

const handleCurrentChange = (val) => {
  currentPage.value = val
}

// 初始化
onMounted(() => {
  refreshFiles()
})
</script>

<style scoped>
.file-manager-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.search-input {
  width: 250px;
}

.path-navigation {
  margin-bottom: 20px;
  padding: 10px;
  background-color: #f5f7fa;
  border-radius: 4px;
}

.file-name {
  cursor: pointer;
  color: #409eff;
}

.file-name:hover {
  text-decoration: underline;
}

.preview-container {
  max-height: 70vh;
  overflow: auto;
}

.image-preview {
  text-align: center;
}

.image-preview img {
  max-width: 100%;
  max-height: 60vh;
}

.text-preview {
  font-family: monospace;
}

.unsupported-preview {
  text-align: center;
  padding: 20px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.upload-button {
  display: inline-block;
}
</style>