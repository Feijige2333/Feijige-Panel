<template>
  <div class="settings-notification-container">
    <el-card class="settings-card">
      <template #header>
        <div class="card-header">
          <h3>通知设置</h3>
          <el-button type="primary" @click="saveSettings">保存设置</el-button>
        </div>
      </template>
      
      <el-tabs v-model="activeTab">
        <el-tab-pane label="邮件通知" name="email">
          <el-form :model="emailSettings" label-width="120px">
            <el-form-item label="启用邮件通知">
              <el-switch v-model="emailSettings.enabled"></el-switch>
            </el-form-item>
            
            <el-form-item label="SMTP服务器" :required="emailSettings.enabled">
              <el-input v-model="emailSettings.smtpServer" placeholder="请输入SMTP服务器地址" :disabled="!emailSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="SMTP端口" :required="emailSettings.enabled">
              <el-input-number v-model="emailSettings.smtpPort" :min="1" :max="65535" placeholder="请输入SMTP端口" :disabled="!emailSettings.enabled"></el-input-number>
            </el-form-item>
            
            <el-form-item label="加密方式" :required="emailSettings.enabled">
              <el-select v-model="emailSettings.encryption" placeholder="请选择加密方式" :disabled="!emailSettings.enabled">
                <el-option label="无" value="none"></el-option>
                <el-option label="SSL" value="ssl"></el-option>
                <el-option label="TLS" value="tls"></el-option>
              </el-select>
            </el-form-item>
            
            <el-form-item label="发件人邮箱" :required="emailSettings.enabled">
              <el-input v-model="emailSettings.senderEmail" placeholder="请输入发件人邮箱" :disabled="!emailSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="发件人名称">
              <el-input v-model="emailSettings.senderName" placeholder="请输入发件人名称" :disabled="!emailSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="SMTP用户名" :required="emailSettings.enabled">
              <el-input v-model="emailSettings.username" placeholder="请输入SMTP用户名" :disabled="!emailSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="SMTP密码" :required="emailSettings.enabled">
              <el-input v-model="emailSettings.password" type="password" placeholder="请输入SMTP密码" :disabled="!emailSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item>
              <el-button type="primary" @click="testEmailSettings" :disabled="!emailSettings.enabled">测试邮件发送</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        
        <el-tab-pane label="短信通知" name="sms">
          <el-form :model="smsSettings" label-width="120px">
            <el-form-item label="启用短信通知">
              <el-switch v-model="smsSettings.enabled"></el-switch>
            </el-form-item>
            
            <el-form-item label="短信服务商" :required="smsSettings.enabled">
              <el-select v-model="smsSettings.provider" placeholder="请选择短信服务商" :disabled="!smsSettings.enabled">
                <el-option label="阿里云" value="aliyun"></el-option>
                <el-option label="腾讯云" value="tencent"></el-option>
                <el-option label="华为云" value="huawei"></el-option>
              </el-select>
            </el-form-item>
            
            <el-form-item label="AccessKey" :required="smsSettings.enabled">
              <el-input v-model="smsSettings.accessKey" placeholder="请输入AccessKey" :disabled="!smsSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="SecretKey" :required="smsSettings.enabled">
              <el-input v-model="smsSettings.secretKey" type="password" placeholder="请输入SecretKey" :disabled="!smsSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="短信签名" :required="smsSettings.enabled">
              <el-input v-model="smsSettings.signName" placeholder="请输入短信签名" :disabled="!smsSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="模板ID" :required="smsSettings.enabled">
              <el-input v-model="smsSettings.templateId" placeholder="请输入模板ID" :disabled="!smsSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item>
              <el-button type="primary" @click="testSmsSettings" :disabled="!smsSettings.enabled">测试短信发送</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        
        <el-tab-pane label="微信通知" name="wechat">
          <el-form :model="wechatSettings" label-width="120px">
            <el-form-item label="启用微信通知">
              <el-switch v-model="wechatSettings.enabled"></el-switch>
            </el-form-item>
            
            <el-form-item label="企业微信ID" :required="wechatSettings.enabled">
              <el-input v-model="wechatSettings.corpId" placeholder="请输入企业微信ID" :disabled="!wechatSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="应用AgentId" :required="wechatSettings.enabled">
              <el-input v-model="wechatSettings.agentId" placeholder="请输入应用AgentId" :disabled="!wechatSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="应用Secret" :required="wechatSettings.enabled">
              <el-input v-model="wechatSettings.secret" type="password" placeholder="请输入应用Secret" :disabled="!wechatSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item>
              <el-button type="primary" @click="testWechatSettings" :disabled="!wechatSettings.enabled">测试微信发送</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        
        <el-tab-pane label="钉钉通知" name="dingtalk">
          <el-form :model="dingtalkSettings" label-width="120px">
            <el-form-item label="启用钉钉通知">
              <el-switch v-model="dingtalkSettings.enabled"></el-switch>
            </el-form-item>
            
            <el-form-item label="Webhook地址" :required="dingtalkSettings.enabled">
              <el-input v-model="dingtalkSettings.webhook" placeholder="请输入钉钉机器人Webhook地址" :disabled="!dingtalkSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item label="安全密钥">
              <el-input v-model="dingtalkSettings.secret" type="password" placeholder="请输入安全密钥(如果有)" :disabled="!dingtalkSettings.enabled"></el-input>
            </el-form-item>
            
            <el-form-item>
              <el-button type="primary" @click="testDingtalkSettings" :disabled="!dingtalkSettings.enabled">测试钉钉发送</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>
      
      <el-divider></el-divider>
      
      <h4>通知事件设置</h4>
      <el-form :model="notificationEvents" label-width="0">
        <el-form-item>
          <el-checkbox-group v-model="notificationEvents.events">
            <el-checkbox label="system_error">系统错误</el-checkbox>
            <el-checkbox label="login_failed">登录失败</el-checkbox>
            <el-checkbox label="disk_warning">磁盘空间警告</el-checkbox>
            <el-checkbox label="cpu_warning">CPU使用率警告</el-checkbox>
            <el-checkbox label="memory_warning">内存使用率警告</el-checkbox>
            <el-checkbox label="backup_complete">备份完成</el-checkbox>
            <el-checkbox label="backup_failed">备份失败</el-checkbox>
            <el-checkbox label="update_available">系统更新可用</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'SettingsNotification',
  data() {
    return {
      activeTab: 'email',
      emailSettings: {
        enabled: false,
        smtpServer: '',
        smtpPort: 465,
        encryption: 'ssl',
        senderEmail: '',
        senderName: '飞机哥面板',
        username: '',
        password: ''
      },
      smsSettings: {
        enabled: false,
        provider: 'aliyun',
        accessKey: '',
        secretKey: '',
        signName: '',
        templateId: ''
      },
      wechatSettings: {
        enabled: false,
        corpId: '',
        agentId: '',
        secret: ''
      },
      dingtalkSettings: {
        enabled: false,
        webhook: '',
        secret: ''
      },
      notificationEvents: {
        events: ['system_error', 'disk_warning', 'backup_failed']
      }
    }
  },
  mounted() {
    this.fetchSettings()
  },
  methods: {
    fetchSettings() {
      // 从API获取通知设置
      // 这里模拟API调用
      setTimeout(() => {
        // 实际项目中应该从API获取数据
        console.log('获取通知设置')
      }, 500)
    },
    saveSettings() {
      // 保存设置到API
      // 这里模拟API调用
      console.log('保存通知设置', {
        email: this.emailSettings,
        sms: this.smsSettings,
        wechat: this.wechatSettings,
        dingtalk: this.dingtalkSettings,
        events: this.notificationEvents
      })
      this.$message.success('通知设置保存成功')
    },
    testEmailSettings() {
      // 测试邮件发送
      this.$prompt('请输入测试接收邮箱', '测试邮件发送', {
        confirmButtonText: '发送',
        cancelButtonText: '取消',
        inputPattern: /[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/,
        inputErrorMessage: '邮箱格式不正确'
      }).then(({ value }) => {
        // 发送测试邮件
        console.log('发送测试邮件到', value)
        this.$message.success(`测试邮件已发送至 ${value}`)
      }).catch(() => {
        this.$message.info('已取消测试邮件发送')
      })
    },
    testSmsSettings() {
      // 测试短信发送
      this.$prompt('请输入测试接收手机号', '测试短信发送', {
        confirmButtonText: '发送',
        cancelButtonText: '取消',
        inputPattern: /^1[3-9]\d{9}$/,
        inputErrorMessage: '手机号格式不正确'
      }).then(({ value }) => {
        // 发送测试短信
        console.log('发送测试短信到', value)
        this.$message.success(`测试短信已发送至 ${value}`)
      }).catch(() => {
        this.$message.info('已取消测试短信发送')
      })
    },
    testWechatSettings() {
      // 测试微信发送
      this.$confirm('确定要发送测试消息到企业微信应用吗？', '测试微信发送', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info'
      }).then(() => {
        // 发送测试微信消息
        console.log('发送测试微信消息')
        this.$message.success('测试微信消息已发送')
      }).catch(() => {
        this.$message.info('已取消测试微信消息发送')
      })
    },
    testDingtalkSettings() {
      // 测试钉钉发送
      this.$confirm('确定要发送测试消息到钉钉机器人吗？', '测试钉钉发送', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info'
      }).then(() => {
        // 发送测试钉钉消息
        console.log('发送测试钉钉消息')
        this.$message.success('测试钉钉消息已发送')
      }).catch(() => {
        this.$message.info('已取消测试钉钉消息发送')
      })
    }
  }
}
</script>

<style scoped>
.settings-notification-container {
  padding: 20px;
}

.settings-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style>