<template>
  <div class="settings-backup-container">
    <el-card class="settings-card">
      <template #header>
        <div class="card-header">
          <h3>备份设置</h3>
          <el-button type="primary" @click="saveSettings">保存设置</el-button>
        </div>
      </template>
      
      <el-form :model="backupSettings" label-width="120px">
        <el-form-item label="自动备份">
          <el-switch v-model="backupSettings.autoBackup"></el-switch>
        </el-form-item>
        
        <el-form-item label="备份周期">
          <el-select v-model="backupSettings.backupCycle" placeholder="请选择备份周期" :disabled="!backupSettings.autoBackup">
            <el-option label="每天" value="daily"></el-option>
            <el-option label="每周" value="weekly"></el-option>
            <el-option label="每月" value="monthly"></el-option>
          </el-select>
        </el-form-item>
        
        <el-form-item label="备份时间">
          <el-time-picker v-model="backupSettings.backupTime" format="HH:mm" placeholder="选择时间" :disabled="!backupSettings.autoBackup"></el-time-picker>
        </el-form-item>
        
        <el-form-item label="备份保留数量">
          <el-input-number v-model="backupSettings.backupRetention" :min="1" :max="100" :disabled="!backupSettings.autoBackup"></el-input-number>
          <span class="form-item-hint">超过数量将自动删除最早的备份</span>
        </el-form-item>
        
        <el-form-item label="备份内容">
          <el-checkbox-group v-model="backupSettings.backupContent" :disabled="!backupSettings.autoBackup">
            <el-checkbox label="config">系统配置</el-checkbox>
            <el-checkbox label="database">数据库</el-checkbox>
            <el-checkbox label="website">网站数据</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
    </el-card>
    
    <el-card class="settings-card">
      <template #header>
        <div class="card-header">
          <h3>备份记录</h3>
          <div>
            <el-button type="success" @click="createBackup">立即备份</el-button>
            <el-button type="primary" @click="importBackup">导入备份</el-button>
          </div>
        </div>
      </template>
      
      <el-table :data="backupRecords" style="width: 100%">
        <el-table-column prop="name" label="备份名称" width="180"></el-table-column>
        <el-table-column prop="backupType" label="备份类型" width="120">
          <template #default="scope">
            <el-tag :type="getBackupTypeTag(scope.row.backupType)">{{ getBackupTypeName(scope.row.backupType) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="fileSize" label="文件大小" width="120">
          <template #default="scope">
            {{ formatFileSize(scope.row.fileSize) }}
          </template>
        </el-table-column>
        <el-table-column prop="createdAt" label="创建时间" width="180"></el-table-column>
        <el-table-column prop="description" label="备份描述"></el-table-column>
        <el-table-column label="操作" width="200">
          <template #default="scope">
            <el-button size="small" type="primary" @click="restoreBackup(scope.row)">恢复</el-button>
            <el-button size="small" type="success" @click="downloadBackup(scope.row)">下载</el-button>
            <el-button size="small" type="danger" @click="deleteBackup(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      
      <div class="pagination-container">
        <el-pagination
          background
          layout="prev, pager, next"
          :total="totalBackups"
          :page-size="10"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </el-card>
    
    <!-- 创建备份对话框 -->
    <el-dialog title="创建备份" v-model="createBackupDialogVisible" width="500px">
      <el-form :model="newBackup" label-width="100px">
        <el-form-item label="备份名称">
          <el-input v-model="newBackup.name" placeholder="请输入备份名称"></el-input>
        </el-form-item>
        <el-form-item label="备份类型">
          <el-select v-model="newBackup.backupType" placeholder="请选择备份类型">
            <el-option label="全量备份" value="full"></el-option>
            <el-option label="配置备份" value="config"></el-option>
            <el-option label="数据库备份" value="database"></el-option>
            <el-option label="网站备份" value="website"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备份描述">
          <el-input type="textarea" v-model="newBackup.description" placeholder="请输入备份描述"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="createBackupDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitCreateBackup">确认</el-button>
        </span>
      </template>
    </el-dialog>
    
    <!-- 导入备份对话框 -->
    <el-dialog title="导入备份" v-model="importBackupDialogVisible" width="500px">
      <el-upload
        class="upload-demo"
        drag
        action="/api/settings/backup/import"
        :on-success="handleImportSuccess"
        :on-error="handleImportError"
        :before-upload="beforeImportUpload"
      >
        <el-icon class="el-icon--upload"><upload-filled /></el-icon>
        <div class="el-upload__text">拖拽文件到此处或 <em>点击上传</em></div>
        <template #tip>
          <div class="el-upload__tip">请上传备份文件（.zip格式）</div>
        </template>
      </el-upload>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'SettingsBackup',
  data() {
    return {
      backupSettings: {
        autoBackup: false,
        backupCycle: 'daily',
        backupTime: new Date(2023, 0, 1, 2, 0), // 默认凌晨2点
        backupRetention: 7,
        backupContent: ['config', 'database']
      },
      backupRecords: [],
      totalBackups: 0,
      currentPage: 1,
      createBackupDialogVisible: false,
      importBackupDialogVisible: false,
      newBackup: {
        name: '',
        backupType: 'full',
        description: ''
      }
    }
  },
  mounted() {
    this.fetchSettings()
    this.fetchBackupRecords()
  },
  methods: {
    fetchSettings() {
      // 从API获取备份设置
      // 这里模拟API调用
      setTimeout(() => {
        // 实际项目中应该从API获取数据
        console.log('获取备份设置')
      }, 500)
    },
    saveSettings() {
      // 保存设置到API
      // 这里模拟API调用
      console.log('保存备份设置', this.backupSettings)
      this.$message.success('备份设置保存成功')
    },
    fetchBackupRecords() {
      // 从API获取备份记录
      // 这里模拟API调用
      setTimeout(() => {
        // 模拟数据
        this.backupRecords = [
          {
            id: 1,
            name: '系统全量备份-20230101',
            backupType: 'full',
            fileSize: 1024 * 1024 * 10, // 10MB
            createdAt: '2023-01-01 02:00:00',
            description: '系统自动备份'
          },
          {
            id: 2,
            name: '数据库备份-20230102',
            backupType: 'database',
            fileSize: 1024 * 1024 * 2, // 2MB
            createdAt: '2023-01-02 02:00:00',
            description: '数据库手动备份'
          },
          {
            id: 3,
            name: '配置备份-20230103',
            backupType: 'config',
            fileSize: 1024 * 512, // 512KB
            createdAt: '2023-01-03 02:00:00',
            description: '配置手动备份'
          }
        ]
        this.totalBackups = 3
      }, 500)
    },
    handlePageChange(page) {
      this.currentPage = page
      this.fetchBackupRecords()
    },
    createBackup() {
      this.newBackup = {
        name: `备份-${new Date().toISOString().split('T')[0].replace(/-/g, '')}-${Math.floor(Math.random() * 1000)}`,
        backupType: 'full',
        description: '手动创建的备份'
      }
      this.createBackupDialogVisible = true
    },
    submitCreateBackup() {
      // 提交创建备份请求
      console.log('创建备份', this.newBackup)
      this.$message.success('备份创建成功')
      this.createBackupDialogVisible = false
      // 刷新备份列表
      this.fetchBackupRecords()
    },
    importBackup() {
      this.importBackupDialogVisible = true
    },
    beforeImportUpload(file) {
      const isZip = file.type === 'application/zip' || file.name.endsWith('.zip')
      if (!isZip) {
        this.$message.error('只能上传ZIP格式的备份文件!')
        return false
      }
      return true
    },
    handleImportSuccess() {
      this.$message.success('备份导入成功')
      this.importBackupDialogVisible = false
      this.fetchBackupRecords()
    },
    handleImportError() {
      this.$message.error('备份导入失败')
    },
    restoreBackup(backup) {
      this.$confirm(`确定要恢复备份 ${backup.name} 吗？恢复过程中系统将暂时不可用。`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 发送恢复备份请求
        console.log('恢复备份', backup)
        this.$message.success('备份恢复成功，系统将在5秒后刷新')
        setTimeout(() => {
          window.location.reload()
        }, 5000)
      }).catch(() => {
        this.$message.info('已取消恢复操作')
      })
    },
    downloadBackup(backup) {
      // 下载备份文件
      console.log('下载备份', backup)
      this.$message.success('备份下载已开始')
    },
    deleteBackup(backup) {
      this.$confirm(`确定要删除备份 ${backup.name} 吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 发送删除备份请求
        console.log('删除备份', backup)
        this.$message.success('备份删除成功')
        this.fetchBackupRecords()
      }).catch(() => {
        this.$message.info('已取消删除操作')
      })
    },
    getBackupTypeName(type) {
      const typeMap = {
        'full': '全量备份',
        'config': '配置备份',
        'database': '数据库备份',
        'website': '网站备份'
      }
      return typeMap[type] || type
    },
    getBackupTypeTag(type) {
      const typeMap = {
        'full': 'danger',
        'config': 'success',
        'database': 'warning',
        'website': 'info'
      }
      return typeMap[type] || ''
    },
    formatFileSize(size) {
      if (size < 1024) {
        return size + ' B'
      } else if (size < 1024 * 1024) {
        return (size / 1024).toFixed(2) + ' KB'
      } else if (size < 1024 * 1024 * 1024) {
        return (size / (1024 * 1024)).toFixed(2) + ' MB'
      } else {
        return (size / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
      }
    }
  }
}
</script>

<style scoped>
.settings-backup-container {
  padding: 20px;
}

.settings-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.form-item-hint {
  margin-left: 10px;
  color: #909399;
  font-size: 12px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
</style>