<template>
  <div class="settings-general-container">
    <el-card class="settings-card">
      <template #header>
        <div class="card-header">
          <h3>常规设置</h3>
          <el-button type="primary" @click="saveSettings">保存设置</el-button>
        </div>
      </template>
      
      <el-form :model="generalSettings" label-width="120px">
        <el-form-item label="面板名称">
          <el-input v-model="generalSettings.panelName" placeholder="请输入面板名称"></el-input>
        </el-form-item>
        
        <el-form-item label="面板主题">
          <el-select v-model="generalSettings.theme" placeholder="请选择主题">
            <el-option label="浅色主题" value="light"></el-option>
            <el-option label="深色主题" value="dark"></el-option>
            <el-option label="跟随系统" value="auto"></el-option>
          </el-select>
        </el-form-item>
        
        <el-form-item label="面板语言">
          <el-select v-model="generalSettings.language" placeholder="请选择语言">
            <el-option label="简体中文" value="zh-CN"></el-option>
            <el-option label="英文" value="en-US"></el-option>
          </el-select>
        </el-form-item>
        
        <el-form-item label="会话超时时间">
          <el-input-number v-model="generalSettings.sessionTimeout" :min="1" :max="1440" placeholder="请输入超时时间（分钟）"></el-input-number>
          <span class="form-item-hint">分钟</span>
        </el-form-item>
        
        <el-form-item label="面板端口">
          <el-input-number v-model="generalSettings.panelPort" :min="1" :max="65535" placeholder="请输入面板端口"></el-input-number>
          <span class="form-item-hint">修改后需要重启面板</span>
        </el-form-item>
        
        <el-form-item label="面板访问地址">
          <el-input v-model="generalSettings.panelUrl" placeholder="请输入面板访问地址"></el-input>
          <span class="form-item-hint">例如：http://localhost:8888</span>
        </el-form-item>
        
        <el-form-item label="开启调试模式">
          <el-switch v-model="generalSettings.debugMode"></el-switch>
          <span class="form-item-hint">开启后将显示详细错误信息，生产环境建议关闭</span>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'SettingsGeneral',
  data() {
    return {
      generalSettings: {
        panelName: '飞机哥面板',
        theme: 'light',
        language: 'zh-CN',
        sessionTimeout: 30,
        panelPort: 8888,
        panelUrl: 'http://localhost:8888',
        debugMode: false
      }
    }
  },
  mounted() {
    this.fetchSettings()
  },
  methods: {
    fetchSettings() {
      // 从API获取设置
      // 这里模拟API调用
      setTimeout(() => {
        // 实际项目中应该从API获取数据
        console.log('获取系统设置')
      }, 500)
    },
    saveSettings() {
      // 保存设置到API
      // 这里模拟API调用
      console.log('保存设置', this.generalSettings)
      this.$message.success('设置保存成功')
    }
  }
}
</script>

<style scoped>
.settings-general-container {
  padding: 20px;
}

.settings-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.form-item-hint {
  margin-left: 10px;
  color: #909399;
  font-size: 12px;
}
</style>