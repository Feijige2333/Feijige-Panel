<template>
  <div class="user-create-container">
    <el-card class="user-card">
      <template #header>
        <div class="card-header">
          <h3>创建用户</h3>
        </div>
      </template>
      
      <el-form :model="userForm" :rules="userRules" ref="userForm" label-width="120px">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="userForm.username" placeholder="请输入用户名" @blur="checkUsernameExist"></el-input>
        </el-form-item>
        
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="userForm.email" placeholder="请输入邮箱"></el-input>
        </el-form-item>
        
        <el-form-item label="密码" prop="password">
          <el-input v-model="userForm.password" type="password" placeholder="请输入密码"></el-input>
        </el-form-item>
        
        <el-form-item label="确认密码" prop="confirmPassword">
          <el-input v-model="userForm.confirmPassword" type="password" placeholder="请再次输入密码"></el-input>
        </el-form-item>
        
        <el-form-item label="角色" prop="role">
          <el-select v-model="userForm.role" placeholder="请选择角色" @change="handleRoleChange">
            <el-option label="管理员" value="admin"></el-option>
            <el-option label="网站管理员" value="website"></el-option>
            <el-option label="数据库管理员" value="database"></el-option>
            <el-option label="安全管理员" value="security"></el-option>
            <el-option label="普通用户" value="user"></el-option>
          </el-select>
        </el-form-item>
        
        <el-form-item label="手机号码" prop="phone">
          <el-input v-model="userForm.phone" placeholder="请输入手机号码"></el-input>
        </el-form-item>
        
        <el-form-item label="头像">
          <el-upload
            class="avatar-uploader"
            action="/api/user/upload-avatar"
            :show-file-list="false"
            :on-success="handleAvatarSuccess"
            :before-upload="beforeAvatarUpload"
          >
            <img v-if="userForm.avatar" :src="userForm.avatar" class="avatar" />
            <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
          </el-upload>
        </el-form-item>
        
        <el-form-item label="权限设置">
          <el-checkbox-group v-model="userForm.permissions">
            <el-checkbox label="admin">系统管理权限</el-checkbox>
            <el-checkbox label="website">网站管理权限</el-checkbox>
            <el-checkbox label="database">数据库管理权限</el-checkbox>
            <el-checkbox label="security">安全管理权限</el-checkbox>
            <el-checkbox label="view_only">只读权限</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        
        <el-form-item>
          <el-button type="primary" @click="submitForm">创建用户</el-button>
          <el-button @click="resetForm">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { userService } from '@/api/user';
import { ElMessage, ElLoading } from 'element-plus';

export default {
  name: 'UserCreate',
  data() {
    const validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.userForm.confirmPassword !== '') {
          this.$refs.userForm.validateField('confirmPassword')
        }
        callback()
      }
    }
    const validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.userForm.password) {
        callback(new Error('两次输入密码不一致'))
      } else {
        callback()
      }
    }
    const validatePhone = (rule, value, callback) => {
      if (value && !/^1[3-9]\d{9}$/.test(value)) {
        callback(new Error('请输入正确的手机号码'))
      } else {
        callback()
      }
    }
    const validatePermissions = (rule, value, callback) => {
      if (!value || value.length === 0) {
        callback(new Error('请至少选择一项权限'))
      } else {
        callback()
      }
    }
    
    return {
      userForm: {
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        role: 'user',
        phone: '',
        avatar: '',
        permissions: ['view_only']
      },
      userRules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱地址', trigger: 'blur' },
          { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { validator: validatePass, trigger: 'blur' },
          { min: 6, message: '密码长度不能少于6个字符', trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '请再次输入密码', trigger: 'blur' },
          { validator: validatePass2, trigger: 'blur' }
        ],
        role: [
          { required: true, message: '请选择角色', trigger: 'change' }
        ],
        phone: [
          { validator: validatePhone, trigger: 'blur' }
        ],
        permissions: [
          { validator: validatePermissions, trigger: 'change' }
        ]
      }
    }
  },
  methods: {
    submitForm() {
      this.$refs.userForm.validate(async (valid) => {
        if (valid) {
          // 创建用户数据对象，移除确认密码字段
          const userData = {
            username: this.userForm.username,
            email: this.userForm.email,
            password: this.userForm.password,
            role: this.userForm.role,
            phone: this.userForm.phone,
            permissions: this.userForm.permissions,
            avatar: this.userForm.avatar
          };
          
          // 显示加载中
          const loading = ElLoading.service({
            lock: true,
            text: '正在创建用户...',
            background: 'rgba(0, 0, 0, 0.7)'
          });
          
          try {
            // 调用API创建用户
            const response = await userService.createUser(userData);
            
            // 创建成功
            ElMessage({
              type: 'success',
              message: '用户创建成功'
            });
            
            // 重置表单
            this.resetForm();
            
            // 跳转到用户列表页面
            this.$router.push('/users');
          } catch (error) {
            // 处理错误
            ElMessage({
              type: 'error',
              message: error.response?.data?.message || '创建用户失败，请稍后重试'
            });
            console.error('创建用户失败:', error);
          } finally {
            // 关闭加载中
            loading.close();
          }
        } else {
          ElMessage({
            type: 'error',
            message: '表单验证失败，请检查输入'
          });
          return false;
        }
      });
    },
    resetForm() {
      this.$refs.userForm.resetFields()
      this.userForm.avatar = ''
      this.userForm.permissions = ['view_only']
    },
    handleAvatarSuccess(res, file) {
      // 上传头像成功后的处理
      if (res.code === 200) {
        this.userForm.avatar = res.data.url;
        ElMessage({
          type: 'success',
          message: '头像上传成功'
        });
      } else {
        ElMessage({
          type: 'error',
          message: res.message || '头像上传失败'
        });
        // 失败时重置头像
        this.userForm.avatar = '';
      }
    },
    beforeAvatarUpload(file) {
      // 上传头像前的验证
      const isJPG = file.type === 'image/jpeg';
      const isPNG = file.type === 'image/png';
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG && !isPNG) {
        ElMessage({
          type: 'error',
          message: '头像只能是 JPG 或 PNG 格式!'
        });
      }
      if (!isLt2M) {
        ElMessage({
          type: 'error',
          message: '头像大小不能超过 2MB!'
        });
      }
      return (isJPG || isPNG) && isLt2M;
    },
    
    // 检查用户名是否已存在
    async checkUsernameExist() {
      if (this.userForm.username && this.userForm.username.length >= 3) {
        try {
          const response = await userService.getUserList();
          const users = response.data || [];
          const isExist = users.some(user => user.username === this.userForm.username);
          
          if (isExist) {
            ElMessage({
              type: 'warning',
              message: '该用户名已存在，请更换其他用户名'
            });
          }
        } catch (error) {
          console.error('检查用户名失败:', error);
        }
      }
    },
    
    // 根据角色自动设置权限
    handleRoleChange(role) {
      // 根据角色设置默认权限
      switch(role) {
        case 'admin':
          this.userForm.permissions = ['admin', 'website', 'database', 'security', 'view_only'];
          break;
        case 'website':
          this.userForm.permissions = ['website', 'view_only'];
          break;
        case 'database':
          this.userForm.permissions = ['database', 'view_only'];
          break;
        case 'security':
          this.userForm.permissions = ['security', 'view_only'];
          break;
        case 'user':
          this.userForm.permissions = ['view_only'];
          break;
        default:
          this.userForm.permissions = ['view_only'];
      }
    }
  }
}
</script>

<style scoped>
.user-create-container {
  padding: 20px;
}

.user-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.avatar-uploader {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  width: 178px;
  height: 178px;
}

.avatar-uploader:hover {
  border-color: #409EFF;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}

.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>