<template>
  <div class="user-list-container">
    <el-card class="user-card">
      <template #header>
        <div class="card-header">
          <h3>用户列表</h3>
          <el-button type="primary" @click="createUser">创建用户</el-button>
        </div>
      </template>
      
      <el-table :data="users" style="width: 100%">
        <el-table-column prop="username" label="用户名" width="150"></el-table-column>
        <el-table-column prop="email" label="邮箱" width="200"></el-table-column>
        <el-table-column prop="role" label="角色" width="120">
          <template #default="scope">
            <el-tag :type="getRoleTagType(scope.row.role)">{{ getRoleName(scope.row.role) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="lastLogin" label="最后登录" width="180"></el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === 'active' ? 'success' : 'danger'">
              {{ scope.row.status === 'active' ? '正常' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="250">
          <template #default="scope">
            <el-button size="small" @click="editUser(scope.row)">编辑</el-button>
            <el-button size="small" type="success" @click="setPermissions(scope.row)">权限</el-button>
            <el-button 
              size="small" 
              :type="scope.row.status === 'active' ? 'danger' : 'success'"
              @click="toggleUserStatus(scope.row)"
            >
              {{ scope.row.status === 'active' ? '禁用' : '启用' }}
            </el-button>
            <el-button size="small" type="danger" @click="deleteUser(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      
      <div class="pagination-container">
        <el-pagination
          background
          layout="prev, pager, next"
          :total="totalUsers"
          :page-size="10"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </el-card>
    
    <!-- 编辑用户对话框 -->
    <el-dialog :title="dialogTitle" v-model="userDialogVisible" width="500px">
      <el-form :model="currentUser" label-width="100px" :rules="userRules" ref="userForm">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="currentUser.username" :disabled="editMode"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="currentUser.email"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password" v-if="!editMode">
          <el-input v-model="currentUser.password" type="password"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="confirmPassword" v-if="!editMode">
          <el-input v-model="currentUser.confirmPassword" type="password"></el-input>
        </el-form-item>
        <el-form-item label="角色" prop="role">
          <el-select v-model="currentUser.role" placeholder="请选择角色">
            <el-option label="管理员" value="admin"></el-option>
            <el-option label="网站管理员" value="website"></el-option>
            <el-option label="数据库管理员" value="database"></el-option>
            <el-option label="安全管理员" value="security"></el-option>
            <el-option label="普通用户" value="user"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="userDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitUserForm">确认</el-button>
        </span>
      </template>
    </el-dialog>
    
    <!-- 设置权限对话框 -->
    <el-dialog title="设置用户权限" v-model="permissionDialogVisible" width="500px">
      <el-form :model="currentPermissions" label-width="0">
        <el-form-item>
          <el-checkbox-group v-model="currentPermissions.permissions">
            <el-checkbox label="admin">系统管理权限</el-checkbox>
            <el-checkbox label="website">网站管理权限</el-checkbox>
            <el-checkbox label="database">数据库管理权限</el-checkbox>
            <el-checkbox label="security">安全管理权限</el-checkbox>
            <el-checkbox label="view_only">只读权限</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="permissionDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitPermissions">确认</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'UserList',
  data() {
    const validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.currentUser.confirmPassword !== '') {
          this.$refs.userForm.validateField('confirmPassword')
        }
        callback()
      }
    }
    const validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.currentUser.password) {
        callback(new Error('两次输入密码不一致'))
      } else {
        callback()
      }
    }
    
    return {
      users: [],
      totalUsers: 0,
      currentPage: 1,
      userDialogVisible: false,
      permissionDialogVisible: false,
      editMode: false,
      dialogTitle: '创建用户',
      currentUser: {
        id: null,
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        role: 'user'
      },
      currentPermissions: {
        userId: null,
        permissions: []
      },
      userRules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请输入邮箱地址', trigger: 'blur' },
          { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur', validator: validatePass }
        ],
        confirmPassword: [
          { required: true, message: '请再次输入密码', trigger: 'blur', validator: validatePass2 }
        ],
        role: [
          { required: true, message: '请选择角色', trigger: 'change' }
        ]
      }
    }
  },
  mounted() {
    this.fetchUsers()
  },
  methods: {
    fetchUsers() {
      // 从API获取用户列表
      // 这里模拟API调用
      setTimeout(() => {
        // 模拟数据
        this.users = [
          {
            id: 1,
            username: 'admin',
            email: 'admin@example.com',
            role: 'admin',
            lastLogin: '2023-01-01 12:00:00',
            status: 'active'
          },
          {
            id: 2,
            username: 'webmaster',
            email: 'webmaster@example.com',
            role: 'website',
            lastLogin: '2023-01-02 10:30:00',
            status: 'active'
          },
          {
            id: 3,
            username: 'dbadmin',
            email: 'dbadmin@example.com',
            role: 'database',
            lastLogin: '2023-01-03 09:15:00',
            status: 'inactive'
          }
        ]
        this.totalUsers = 3
      }, 500)
    },
    handlePageChange(page) {
      this.currentPage = page
      this.fetchUsers()
    },
    createUser() {
      this.editMode = false
      this.dialogTitle = '创建用户'
      this.currentUser = {
        id: null,
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        role: 'user'
      }
      this.userDialogVisible = true
    },
    editUser(user) {
      this.editMode = true
      this.dialogTitle = '编辑用户'
      this.currentUser = {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
      this.userDialogVisible = true
    },
    submitUserForm() {
      // 提交用户表单
      console.log('提交用户', this.currentUser)
      this.$message.success(this.editMode ? '用户更新成功' : '用户创建成功')
      this.userDialogVisible = false
      this.fetchUsers()
    },
    setPermissions(user) {
      this.currentPermissions = {
        userId: user.id,
        permissions: ['view_only'] // 默认只有查看权限
      }
      
      // 根据角色设置默认权限
      if (user.role === 'admin') {
        this.currentPermissions.permissions = ['admin', 'website', 'database', 'security']
      } else if (user.role === 'website') {
        this.currentPermissions.permissions = ['website', 'view_only']
      } else if (user.role === 'database') {
        this.currentPermissions.permissions = ['database', 'view_only']
      } else if (user.role === 'security') {
        this.currentPermissions.permissions = ['security', 'view_only']
      }
      
      this.permissionDialogVisible = true
    },
    submitPermissions() {
      // 提交权限设置
      console.log('提交权限', this.currentPermissions)
      this.$message.success('权限设置成功')
      this.permissionDialogVisible = false
    },
    toggleUserStatus(user) {
      const newStatus = user.status === 'active' ? 'inactive' : 'active'
      const action = newStatus === 'active' ? '启用' : '禁用'
      
      this.$confirm(`确定要${action}用户 ${user.username} 吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 发送更新状态请求
        console.log('更新用户状态', user.id, newStatus)
        this.$message.success(`用户${action}成功`)
        // 更新本地状态
        user.status = newStatus
      }).catch(() => {
        this.$message.info('已取消操作')
      })
    },
    deleteUser(user) {
      this.$confirm(`确定要删除用户 ${user.username} 吗？此操作不可恢复！`, '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error'
      }).then(() => {
        // 发送删除用户请求
        console.log('删除用户', user.id)
        this.$message.success('用户删除成功')
        this.fetchUsers()
      }).catch(() => {
        this.$message.info('已取消删除操作')
      })
    },
    getRoleName(role) {
      const roleMap = {
        'admin': '管理员',
        'website': '网站管理员',
        'database': '数据库管理员',
        'security': '安全管理员',
        'user': '普通用户'
      }
      return roleMap[role] || role
    },
    getRoleTagType(role) {
      const typeMap = {
        'admin': 'danger',
        'website': 'success',
        'database': 'warning',
        'security': 'info',
        'user': ''
      }
      return typeMap[role] || ''
    }
  }
}
</script>

<style scoped>
.user-list-container {
  padding: 20px;
}

.user-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
</style>