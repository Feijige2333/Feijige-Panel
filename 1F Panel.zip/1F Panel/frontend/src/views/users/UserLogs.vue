<template>
  <div class="user-logs-container">
    <el-tabs v-model="activeTab">
      <el-tab-pane label="登录日志" name="login">
        <el-card class="logs-card">
          <template #header>
            <div class="card-header">
              <h3>登录日志</h3>
              <div class="filter-container">
                <el-input
                  v-model="loginLogFilters.username"
                  placeholder="用户名"
                  clearable
                  @clear="fetchLoginLogs"
                  style="width: 150px; margin-right: 10px;"
                ></el-input>
                <el-select
                  v-model="loginLogFilters.status"
                  placeholder="登录状态"
                  clearable
                  @clear="fetchLoginLogs"
                  style="width: 120px; margin-right: 10px;"
                >
                  <el-option label="成功" value="success"></el-option>
                  <el-option label="失败" value="failed"></el-option>
                </el-select>
                <el-date-picker
                  v-model="loginLogFilters.dateRange"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  format="YYYY-MM-DD"
                  value-format="YYYY-MM-DD"
                  @change="fetchLoginLogs"
                  style="width: 260px; margin-right: 10px;"
                ></el-date-picker>
                <el-button type="primary" @click="fetchLoginLogs">查询</el-button>
              </div>
            </div>
          </template>
          
          <el-table :data="loginLogs" style="width: 100%">
            <el-table-column prop="username" label="用户名" width="120"></el-table-column>
            <el-table-column prop="ipAddress" label="IP地址" width="150"></el-table-column>
            <el-table-column prop="userAgent" label="浏览器信息" width="200">
              <template #default="scope">
                <el-tooltip :content="scope.row.userAgent" placement="top" effect="light">
                  <span>{{ truncateText(scope.row.userAgent, 30) }}</span>
                </el-tooltip>
              </template>
            </el-table-column>
            <el-table-column prop="loginTime" label="登录时间" width="180"></el-table-column>
            <el-table-column prop="loginStatus" label="登录状态" width="100">
              <template #default="scope">
                <el-tag :type="scope.row.loginStatus ? 'success' : 'danger'">
                  {{ scope.row.loginStatus ? '成功' : '失败' }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>
          
          <div class="pagination-container">
            <el-pagination
              background
              layout="prev, pager, next"
              :total="totalLoginLogs"
              :page-size="10"
              @current-change="handleLoginLogPageChange"
            ></el-pagination>
          </div>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="操作日志" name="operation">
        <el-card class="logs-card">
          <template #header>
            <div class="card-header">
              <h3>操作日志</h3>
              <div class="filter-container">
                <el-input
                  v-model="operationLogFilters.username"
                  placeholder="用户名"
                  clearable
                  @clear="fetchOperationLogs"
                  style="width: 150px; margin-right: 10px;"
                ></el-input>
                <el-select
                  v-model="operationLogFilters.module"
                  placeholder="操作模块"
                  clearable
                  @clear="fetchOperationLogs"
                  style="width: 120px; margin-right: 10px;"
                >
                  <el-option label="服务器管理" value="server"></el-option>
                  <el-option label="网站管理" value="website"></el-option>
                  <el-option label="数据库管理" value="database"></el-option>
                  <el-option label="安全管理" value="security"></el-option>
                  <el-option label="用户管理" value="user"></el-option>
                  <el-option label="系统设置" value="setting"></el-option>
                </el-select>
                <el-select
                  v-model="operationLogFilters.action"
                  placeholder="操作类型"
                  clearable
                  @clear="fetchOperationLogs"
                  style="width: 120px; margin-right: 10px;"
                >
                  <el-option label="创建" value="create"></el-option>
                  <el-option label="更新" value="update"></el-option>
                  <el-option label="删除" value="delete"></el-option>
                  <el-option label="查看" value="view"></el-option>
                  <el-option label="其他" value="other"></el-option>
                </el-select>
                <el-date-picker
                  v-model="operationLogFilters.dateRange"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  format="YYYY-MM-DD"
                  value-format="YYYY-MM-DD"
                  @change="fetchOperationLogs"
                  style="width: 260px; margin-right: 10px;"
                ></el-date-picker>
                <el-button type="primary" @click="fetchOperationLogs">查询</el-button>
              </div>
            </div>
          </template>
          
          <el-table :data="operationLogs" style="width: 100%">
            <el-table-column prop="username" label="用户名" width="120"></el-table-column>
            <el-table-column prop="moduleName" label="操作模块" width="120"></el-table-column>
            <el-table-column prop="actionName" label="操作类型" width="100"></el-table-column>
            <el-table-column prop="detail" label="操作详情" width="250">
              <template #default="scope">
                <el-tooltip :content="scope.row.detail" placement="top" effect="light">
                  <span>{{ truncateText(scope.row.detail, 40) }}</span>
                </el-tooltip>
              </template>
            </el-table-column>
            <el-table-column prop="ipAddress" label="IP地址" width="150"></el-table-column>
            <el-table-column prop="operationTime" label="操作时间" width="180"></el-table-column>
          </el-table>
          
          <div class="pagination-container">
            <el-pagination
              background
              layout="prev, pager, next"
              :total="totalOperationLogs"
              :page-size="10"
              @current-change="handleOperationLogPageChange"
            ></el-pagination>
          </div>
        </el-card>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
export default {
  name: 'UserLogs',
  data() {
    return {
      activeTab: 'login',
      loginLogs: [],
      operationLogs: [],
      totalLoginLogs: 0,
      totalOperationLogs: 0,
      loginLogCurrentPage: 1,
      operationLogCurrentPage: 1,
      loginLogFilters: {
        username: '',
        status: '',
        dateRange: []
      },
      operationLogFilters: {
        username: '',
        module: '',
        action: '',
        dateRange: []
      }
    }
  },
  mounted() {
    this.fetchLoginLogs()
    this.fetchOperationLogs()
  },
  methods: {
    fetchLoginLogs() {
      // 从API获取登录日志
      // 这里模拟API调用
      setTimeout(() => {
        // 模拟数据
        this.loginLogs = [
          {
            id: 1,
            username: 'admin',
            ipAddress: '192.168.1.100',
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            loginTime: '2023-01-01 12:00:00',
            loginStatus: true
          },
          {
            id: 2,
            username: 'webmaster',
            ipAddress: '192.168.1.101',
            userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
            loginTime: '2023-01-02 10:30:00',
            loginStatus: true
          },
          {
            id: 3,
            username: 'unknown',
            ipAddress: '192.168.1.102',
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            loginTime: '2023-01-03 09:15:00',
            loginStatus: false
          }
        ]
        this.totalLoginLogs = 3
      }, 500)
    },
    fetchOperationLogs() {
      // 从API获取操作日志
      // 这里模拟API调用
      setTimeout(() => {
        // 模拟数据
        this.operationLogs = [
          {
            id: 1,
            username: 'admin',
            moduleName: '用户管理',
            actionName: '创建',
            detail: '创建用户: webmaster',
            ipAddress: '192.168.1.100',
            operationTime: '2023-01-01 12:05:00'
          },
          {
            id: 2,
            username: 'admin',
            moduleName: '系统设置',
            actionName: '更新',
            detail: '更新系统设置: 备份设置',
            ipAddress: '192.168.1.100',
            operationTime: '2023-01-01 12:10:00'
          },
          {
            id: 3,
            username: 'webmaster',
            moduleName: '网站管理',
            actionName: '创建',
            detail: '创建网站: example.com',
            ipAddress: '192.168.1.101',
            operationTime: '2023-01-02 10:35:00'
          }
        ]
        this.totalOperationLogs = 3
      }, 500)
    },
    handleLoginLogPageChange(page) {
      this.loginLogCurrentPage = page
      this.fetchLoginLogs()
    },
    handleOperationLogPageChange(page) {
      this.operationLogCurrentPage = page
      this.fetchOperationLogs()
    },
    truncateText(text, length) {
      if (text && text.length > length) {
        return text.substring(0, length) + '...'
      }
      return text
    }
  }
}
</script>

<style scoped>
.user-logs-container {
  padding: 20px;
}

.logs-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  flex-direction: column;
}

.filter-container {
  margin-top: 15px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}
</style>